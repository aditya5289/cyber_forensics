"""Analysis session — the XAMN half of the suite (lab manual §6).

An :class:`AnalysisSession` opens one or more sealed containers read-only and
exposes every view the manual asks for:

===============================  =====================================
Manual step                      Method
===============================  =====================================
14  Case info + category counts  :meth:`overview`
15  Pictures & Videos gallery    :meth:`gallery`
16  Call records list            :meth:`list_view`
17  Connection view (calls)      :meth:`connections`
18  Per-application artifacts    :meth:`application`
19  Connection view (messages)   :meth:`connections`
20  Contacts column view         :meth:`column_view`
21  Report / export              :mod:`argus.report`
===============================  =====================================

Containers are opened **read-only and verified on open**.  If a container's
seal does not match, the session still opens — an examiner needs to be able to
look at damaged evidence — but every response carries the integrity failure so
it cannot be reported as sound.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from ..core.container import EvidenceContainer
from ..core.db import ArtifactDB
from ..core.models import Artifact, Category, Recovery
from ..parsers.timestamps import to_iso
from . import search as aql
from .graph import ConnectionGraph, build_graph
from .timeline import build as build_timeline, summarise


@dataclass
class LoadedContainer:
    container: EvidenceContainer
    verification: Dict[str, Any] = field(default_factory=dict)

    @property
    def db(self) -> ArtifactDB:
        return self.container.db

    @property
    def name(self) -> str:
        return self.container.path.name


class AnalysisSession:
    """Read-only analysis over one or more evidence containers."""

    def __init__(self, paths: Iterable[Path | str], deep_verify: bool = False,
                 owner_label: str = "Device owner",
                 tz_offset_minutes: int = 0):
        self.owner_label = owner_label
        self.tz_offset = tz_offset_minutes
        self.loaded: List[LoadedContainer] = []
        for p in paths:
            container = EvidenceContainer(Path(p), mode="r")
            self.loaded.append(LoadedContainer(
                container=container,
                verification=container.verify(deep=deep_verify)))
        if not self.loaded:
            raise ValueError("no containers supplied to the analysis session")
        self._graph_cache: Dict[str, ConnectionGraph] = {}

    # ------------------------------------------------------------- plumbing
    @property
    def primary(self) -> LoadedContainer:
        return self.loaded[0]

    def _all_artifacts(self, where: str = "", params: tuple = ()
                       ) -> List[Artifact]:
        out: List[Artifact] = []
        for lc in self.loaded:
            out.extend(lc.db.iter_artifacts(where, params))
        return out

    def _merge_counts(self, method: str) -> Dict[str, int]:
        merged: Dict[str, int] = {}
        for lc in self.loaded:
            for k, v in getattr(lc.db, method)().items():
                merged[k] = merged.get(k, 0) + v
        return dict(sorted(merged.items(), key=lambda kv: -kv[1]))

    @property
    def integrity_ok(self) -> bool:
        return all(lc.verification.get("ok") for lc in self.loaded)

    def integrity_report(self) -> Dict[str, Any]:
        return {
            "ok": self.integrity_ok,
            "containers": [
                {"name": lc.name, **lc.verification} for lc in self.loaded
            ],
        }

    # ------------------------------------------------------- Step 14 overview
    def overview(self) -> Dict[str, Any]:
        """Case info, data sources and category-wise artifact counts."""
        extraction = self.primary.container.extraction
        total = sum(lc.db.count() for lc in self.loaded)
        lo_all, hi_all = [], []
        for lc in self.loaded:
            lo, hi = lc.db.time_bounds()
            if lo:
                lo_all.append(lo)
            if hi:
                hi_all.append(hi)

        recovery = self._merge_counts("recovery_counts")
        return {
            "case_id": extraction.get("case_id", ""),
            "exhibit_id": extraction.get("exhibit_id", ""),
            "operator": extraction.get("operator", ""),
            "method": extraction.get("method", ""),
            "time_span": extraction.get("time_span", ""),
            "created_at": self.primary.container.manifest.get("created_at", ""),
            "started_at": extraction.get("started_at", ""),
            "finished_at": extraction.get("finished_at", ""),
            "device": {
                "make": extraction.get("device_make", ""),
                "model": extraction.get("device_model", ""),
                "os": extraction.get("device_os", ""),
                "serial": extraction.get("device_serial", ""),
                "imei": extraction.get("imei", ""),
                "iccid": extraction.get("iccid", ""),
                "phone_number": extraction.get("phone_number", ""),
                "lock_state": extraction.get("lock_state", ""),
            },
            "encryption_level": (
                "Sealed (Merkle + hash-chained audit)"
                if self.primary.container.sealed else "Unsealed — in progress"),
            "containers": [
                {"name": lc.name, "artifacts": lc.db.count(),
                 "sealed": lc.container.sealed,
                 "integrity_ok": lc.verification.get("ok", False),
                 "problems": lc.verification.get("problems", [])}
                for lc in self.loaded
            ],
            "total_artifacts": total,
            "categories": self._merge_counts("category_counts"),
            "applications": self._merge_counts("app_counts"),
            "recovery": recovery,
            "deleted_recovered": sum(
                v for k, v in recovery.items() if k != Recovery.ALLOCATED.value),
            "first_activity": to_iso(min(lo_all), self.tz_offset) if lo_all else "",
            "last_activity": to_iso(max(hi_all), self.tz_offset) if hi_all else "",
            "data_sources": [s for lc in self.loaded for s in lc.db.sources()],
            "tags": self._merged_tags(),
            "integrity": self.integrity_report(),
        }

    def _merged_tags(self) -> List[Dict[str, Any]]:
        merged: Dict[str, Dict[str, Any]] = {}
        for lc in self.loaded:
            for t in lc.db.tag_names():
                cur = merged.setdefault(t["name"], {"name": t["name"],
                                                    "colour": t["colour"],
                                                    "count": 0})
                cur["count"] += t["count"]
        return sorted(merged.values(), key=lambda t: -t["count"])

    # --------------------------------------------------------------- queries
    def query(self, aql_text: str = "", limit: int = 500, offset: int = 0,
              order: str = "timestamp DESC") -> Dict[str, Any]:
        """Run an AQL query across every loaded container."""
        compiled = aql.compile_query(aql_text)
        artifacts: List[Artifact] = []
        total = 0
        for lc in self.loaded:
            total += lc.db.count(compiled.where, compiled.params)
            artifacts.extend(lc.db.iter_artifacts(
                compiled.where, compiled.params, order=order,
                limit=limit + offset))
        reverse = "DESC" in order.upper()
        artifacts.sort(key=lambda a: (a.timestamp is None,
                                      a.timestamp or 0), reverse=reverse)
        window = artifacts[offset:offset + limit]
        return {
            "query": aql_text,
            "sql_where": compiled.where,
            "total": total,
            "returned": len(window),
            "offset": offset,
            "artifacts": [self._render(a) for a in window],
        }

    def get(self, artifact_id: str) -> Optional[Dict[str, Any]]:
        for lc in self.loaded:
            art = lc.db.get(artifact_id)
            if art:
                rendered = self._render(art, full=True)
                rendered["container"] = lc.name
                return rendered
        return None

    def _render(self, art: Artifact, full: bool = False) -> Dict[str, Any]:
        d = {
            "artifact_id": art.artifact_id,
            "category": art.category.value,
            "subtype": art.subtype,
            "timestamp": art.timestamp,
            "timestamp_iso": to_iso(art.timestamp, self.tz_offset),
            "app": art.app,
            "direction": art.direction.value,
            "body": art.body if full else art.summary(400),
            "parties": [{"label": p.label(), "identifier": p.identifier,
                         "role": p.role, "is_owner": p.is_owner}
                        for p in art.participants],
            "recovery": art.recovery.value,
            "is_deleted": art.recovery != Recovery.ALLOCATED,
            "confidence": art.confidence,
            "source_path": art.source_path,
            "source_table": art.source_table,
            "source_row": art.source_row,
            "blob_sha256": art.blob_sha256,
            "latitude": art.latitude, "longitude": art.longitude,
            "tags": art.tags,
        }
        if full:
            d["attributes"] = art.attributes
            d["timestamp_end"] = art.timestamp_end
            if art.blob_sha256:
                for lc in self.loaded:
                    info = lc.db.blob_info(art.blob_sha256)
                    if info:
                        d["blob"] = info
                        break
        else:
            # These are the attributes an examiner needs to see *in the list*,
            # not only after opening an artifact — each one changes how the row
            # should be read.
            d["attributes"] = {
                k: v for k, v in art.attributes.items()
                if k in ("duration_display", "duration_seconds", "filename",
                         "size_display", "url", "domain", "media_kind",
                         "is_group", "chat_name", "display_name",
                         "phone_numbers", "attachment_count", "mime_type",
                         "extension_mismatch", "has_gps", "search_terms",
                         # provenance and reliability flags
                         "previews_encrypted_app", "encrypted", "concealed",
                         "partial_record", "columns_unrecoverable",
                         "content_recovered", "extraction_method",
                         "schema_variant", "amount", "counterparty",
                         "package", "event", "duration_seconds", "stream")
            }
        return d

    # ------------------------------------------- Step 15 gallery (§6.2)
    def gallery(self, only_images: bool = False, with_gps: bool = False,
                app: str = "", limit: int = 500,
                offset: int = 0) -> Dict[str, Any]:
        """Pictures & Videos quick view, filterable by time, location and app."""
        clauses = [f"category = '{Category.FILE.value}'"]
        params: List[Any] = []
        if only_images:
            clauses.append("subtype = 'Picture'")
        else:
            clauses.append("subtype IN ('Picture','Video')")
        if with_gps:
            clauses.append("latitude IS NOT NULL")
        if app:
            clauses.append("app = ?")
            params.append(app)
        where = " AND ".join(clauses)

        items, total = [], 0
        for lc in self.loaded:
            total += lc.db.count(where, tuple(params))
            for art in lc.db.iter_artifacts(where, tuple(params),
                                            order="timestamp DESC",
                                            limit=limit, offset=offset):
                items.append({
                    **self._render(art),
                    "container": lc.name,
                    "filename": art.attributes.get("filename", ""),
                    "size_display": art.attributes.get("size_display", ""),
                    "mime_type": art.attributes.get("mime_type", ""),
                    "dimensions": _dimensions(art),
                    "map_url": art.attributes.get("map_url", ""),
                })
        return {"total": total, "returned": len(items), "items": items,
                "apps": [a for a in self._merge_counts("app_counts")]}

    # ------------------------------------------- Step 16/20 list & column view
    def list_view(self, category: str, limit: int = 1000,
                  offset: int = 0) -> Dict[str, Any]:
        cat = Category.coerce(category).value
        return self.query(f'category:"{cat}"', limit=limit, offset=offset)

    def column_view(self, category: str, limit: int = 2000) -> Dict[str, Any]:
        """Flat tabular projection — the manual's 'Column view' (Fig. 6.7)."""
        cat = Category.coerce(category)
        rows: List[Dict[str, Any]] = []
        columns = _COLUMNS.get(cat, _COLUMNS[Category.OTHER])
        for lc in self.loaded:
            for art in lc.db.iter_artifacts("category = ?", (cat.value,),
                                            order="timestamp DESC", limit=limit):
                rows.append(_project(art, columns, self.tz_offset))
        return {"category": cat.value, "columns": [c[0] for c in columns],
                "rows": rows, "count": len(rows)}

    # ----------------------------------- Steps 17/19 connection view (§6.4/6.6)
    def connections(self, scope: str = "all", min_weight: int = 1,
                    max_nodes: int = 300) -> Dict[str, Any]:
        """Communication graph. ``scope``: all | calls | messages."""
        key = f"{scope}:{min_weight}"
        graph = self._graph_cache.get(key)
        if graph is None:
            where, params = "", ()
            if scope == "calls":
                where, params = "category = ?", (Category.CALL.value,)
            elif scope == "messages":
                where, params = ("category IN (?,?)",
                                 (Category.MESSAGE.value, Category.CHAT.value))
            graph = ConnectionGraph(owner_label=self.owner_label)
            for lc in self.loaded:
                graph.learn_contacts(lc.db.iter_artifacts(
                    "category = ?", (Category.CONTACT.value,)))
            for lc in self.loaded:
                graph.add(lc.db.iter_artifacts(where, params))
            graph.finalise()
            self._graph_cache[key] = graph

        data = graph.to_dict(min_weight=min_weight, max_nodes=max_nodes)
        data["scope"] = scope
        data["top_contacts"] = graph.top_contacts(15)
        data["brokers"] = graph.brokers(8)
        data["one_way"] = graph.one_way_contacts()[:10]
        return data

    # ---------------------------------------- Step 18 per-application (§6.5)
    def applications(self) -> List[Dict[str, Any]]:
        counts = self._merge_counts("app_counts")
        out = []
        for app, count in counts.items():
            cats: Dict[str, int] = {}
            for lc in self.loaded:
                for r in lc.db.conn.execute(
                        "SELECT category, COUNT(*) c FROM artifact WHERE app=? "
                        "GROUP BY category", (app,)):
                    cats[r["category"]] = cats.get(r["category"], 0) + r["c"]
            out.append({"app": app, "count": count, "categories": cats})
        return out

    def application(self, app: str, limit: int = 500) -> Dict[str, Any]:
        result = self.query(f'app:"{app}"', limit=limit)
        media = [a for a in result["artifacts"]
                 if a["category"] == Category.FILE.value]
        result["app"] = app
        result["media_count"] = len(media)
        return result

    # ------------------------------------------------------------- analytics
    def timeline(self, aql_text: str = "", limit: int = 20000
                 ) -> Dict[str, Any]:
        compiled = aql.compile_query(aql_text)
        artifacts = []
        for lc in self.loaded:
            artifacts.extend(lc.db.iter_artifacts(
                compiled.where, compiled.params, limit=limit))
        entries = build_timeline(artifacts, self.tz_offset)
        return {"query": aql_text, "count": len(entries),
                "entries": [e.as_dict() for e in entries]}

    def statistics(self, aql_text: str = "") -> Dict[str, Any]:
        compiled = aql.compile_query(aql_text)
        artifacts = []
        for lc in self.loaded:
            artifacts.extend(lc.db.iter_artifacts(compiled.where, compiled.params))
        return summarise(artifacts, self.tz_offset)

    def places(self) -> Dict[str, Any]:
        """Every geolocated artifact, for the map view."""
        points = []
        for lc in self.loaded:
            for art in lc.db.iter_artifacts(
                    "latitude IS NOT NULL AND longitude IS NOT NULL",
                    order="timestamp ASC"):
                points.append({
                    "artifact_id": art.artifact_id,
                    "latitude": art.latitude, "longitude": art.longitude,
                    "timestamp": art.timestamp,
                    "iso": to_iso(art.timestamp, self.tz_offset),
                    "category": art.category.value, "app": art.app,
                    "summary": art.summary(90),
                })
        lats = [p["latitude"] for p in points]
        lons = [p["longitude"] for p in points]
        return {
            "count": len(points), "points": points,
            "bounds": {"min_lat": min(lats), "max_lat": max(lats),
                       "min_lon": min(lons), "max_lon": max(lons)} if points else {},
        }

    def deleted(self, limit: int = 1000) -> Dict[str, Any]:
        """Everything recovered from unallocated space, highest confidence first."""
        return self.query("deleted:true", limit=limit,
                          order="confidence DESC, timestamp DESC")

    # ------------------------------------------------------------------ tags
    def tag(self, artifact_id: str, name: str, colour: str = "#e2b33c",
            note: str = "", actor: str = "") -> bool:
        """Tagging writes to a sidecar DB so sealed evidence stays untouched."""
        for lc in self.loaded:
            if lc.db.get(artifact_id):
                sidecar = ArtifactDB(lc.container.path.parent /
                                     f"{lc.name}.analysis.db")
                sidecar.conn.execute(
                    "INSERT OR REPLACE INTO tag VALUES (?,?,?,?,datetime('now'),?)",
                    (artifact_id, name, colour, note, actor))
                sidecar.conn.commit()
                sidecar.close()
                return True
        return False

    def blob(self, sha256: str) -> Optional[Tuple[bytes, str]]:
        """Return ``(bytes, mime)`` for a stored blob."""
        for lc in self.loaded:
            if lc.container.has_blob(sha256):
                info = lc.db.blob_info(sha256) or {}
                return (lc.container.open_blob(sha256),
                        info.get("mime", "application/octet-stream"))
        return None

    def intelligence(self, owner_identifiers: Optional[List[str]] = None
                     ) -> Dict[str, Any]:
        """Findings, entities, correlation and community structure.

        Cached per session: the rules walk every artifact several times, and an
        examiner switching between views should not pay for that repeatedly.
        """
        key = tuple(sorted(owner_identifiers or ()))
        cached = getattr(self, "_intel_cache", {}).get(key)
        if cached is not None:
            return cached
        from ..intel import analyse
        result = analyse(self, owner_name=self.owner_label,
                         owner_identifiers=owner_identifiers or [])
        if not hasattr(self, "_intel_cache"):
            self._intel_cache = {}
        self._intel_cache[key] = result
        return result

    def extraction_log(self) -> List[Dict[str, Any]]:
        out = []
        for lc in self.loaded:
            for e in lc.container.log_entries():
                out.append({**e, "container": lc.name})
        return sorted(out, key=lambda e: e.get("ts", ""))

    def audit_trail(self) -> List[Dict[str, Any]]:
        out = []
        for lc in self.loaded:
            for e in lc.container.audit.entries():
                out.append({**e, "container": lc.name})
        return out

    def close(self) -> None:
        for lc in self.loaded:
            lc.container.close()

    def __enter__(self) -> "AnalysisSession":
        return self

    def __exit__(self, *exc) -> None:
        self.close()


# --------------------------------------------------------------- projections
_COLUMNS: Dict[Category, List[Tuple[str, str]]] = {
    Category.CONTACT: [
        ("Name", "attr:display_name"), ("Phone numbers", "attr:phone_numbers"),
        ("Emails", "attr:emails"), ("Organisation", "attr:organisation"),
        ("Account", "attr:account_name"), ("Source", "app"),
        ("Recovery", "recovery"), ("Modified", "time"),
    ],
    Category.CALL: [
        ("Time", "time"), ("Type", "subtype"), ("Party", "parties"),
        ("Direction", "direction"), ("Duration", "attr:duration_display"),
        ("App", "app"), ("Recovery", "recovery"),
    ],
    Category.MESSAGE: [
        ("Time", "time"), ("Type", "subtype"), ("Direction", "direction"),
        ("Party", "parties"), ("Message", "body"), ("App", "app"),
        ("Recovery", "recovery"),
    ],
    Category.FILE: [
        ("Time", "time"), ("Filename", "attr:filename"),
        ("Type", "attr:mime_type"), ("Size", "attr:size_display"),
        ("Source app", "app"), ("Path", "source_path"), ("SHA-256", "sha"),
    ],
    Category.WEB: [
        ("Time", "time"), ("Type", "subtype"), ("Title", "body"),
        ("URL", "attr:url"), ("Domain", "attr:domain"), ("App", "app"),
        ("Recovery", "recovery"),
    ],
    Category.PLACE: [
        ("Time", "time"), ("Type", "subtype"), ("Latitude", "lat"),
        ("Longitude", "lon"), ("App", "app"),
    ],
    Category.OTHER: [
        ("Time", "time"), ("Category", "category"), ("Type", "subtype"),
        ("Summary", "body"), ("App", "app"), ("Recovery", "recovery"),
    ],
}


def _project(art: Artifact, columns: List[Tuple[str, str]],
             tz: int) -> Dict[str, Any]:
    row: Dict[str, Any] = {"artifact_id": art.artifact_id}
    for label, spec in columns:
        if spec == "time":
            row[label] = to_iso(art.timestamp, tz)
        elif spec == "parties":
            row[label] = ", ".join(p.label() for p in art.counterparties())
        elif spec == "body":
            row[label] = art.summary(200)
        elif spec == "sha":
            row[label] = art.blob_sha256[:16]
        elif spec == "lat":
            row[label] = art.latitude
        elif spec == "lon":
            row[label] = art.longitude
        elif spec.startswith("attr:"):
            v = art.attributes.get(spec[5:], "")
            row[label] = ", ".join(str(x) for x in v) if isinstance(v, list) else v
        else:
            v = getattr(art, spec, "")
            row[label] = v.value if hasattr(v, "value") else v
    return row


def _dimensions(art: Artifact) -> str:
    exif = art.attributes.get("exif") or {}
    w, h = exif.get("width"), exif.get("height")
    return f"{w}×{h}" if w and h else ""
