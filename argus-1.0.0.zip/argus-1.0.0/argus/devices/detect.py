"""Live device detection (lab manual §5.4, Steps 6–7).

Detects connected handsets exactly the way a real acquisition workstation does:

* **Android** via ``adb`` — enumerates devices, reads ``ro.product.*`` build
  properties, IMEI, battery, encryption state and root availability.
* **iOS** via ``libimobiledevice`` (``idevice_id`` / ``ideviceinfo``) — reads
  ProductType, ProductVersion, serial, IMEI and the pairing/trust state.

Both toolchains are optional.  If neither is installed the module degrades
cleanly and reports *why* nothing was found rather than pretending no device
is attached — silently reporting "no device" when the cause is a missing
binary is how examiners lose an hour.
"""

from __future__ import annotations

import re
import os
import shutil
from pathlib import Path
import sys
import subprocess
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from ..core.errors import AcquisitionError

ADB_TIMEOUT = 20


@dataclass
class DetectedDevice:
    """A handset currently attached to the workstation."""

    transport: str                    # "adb" | "usbmux" | "manual"
    serial: str = ""
    make: str = ""
    model: str = ""
    marketing_name: str = ""
    os_family: str = ""
    os_version: str = ""
    build_id: str = ""
    chipset: str = ""
    imei: str = ""
    iccid: str = ""
    phone_number: str = ""
    lock_state: str = "unlocked"
    trusted: bool = True
    rooted: bool = False
    encrypted: bool = True
    battery: Optional[int] = None
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def name(self) -> str:
        return " ".join(filter(None, [self.make, self.marketing_name or self.model]))

    def as_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["name"] = self.name
        return d


def _run(cmd: List[str], timeout: int = ADB_TIMEOUT) -> str:
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout, check=False)
        return (proc.stdout or "").strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return ""


# Install instructions have to match the machine in front of the examiner.
# Telling a Windows user to run `apt install` is not a hint, it is a dead end —
# and on a locked-down workstation they cannot verify it is wrong by trying it.
INSTALL_HINTS: Dict[str, Dict[str, str]] = {
    "adb": {
        # winget frequently installs this package without putting adb on PATH
        # (microsoft/winget-pkgs#103349), so the manual route is listed first —
        # an instruction that appears to succeed and then leaves the tool
        # uncallable wastes more time than one that is plainly manual.
        # The winget route fails in two distinct ways often enough that it is
        # no longer recommended: it installs without putting adb on PATH
        # (microsoft/winget-pkgs#103349), and its manifest hash goes stale
        # because Google republishes the archive in place, producing
        # "Installer hash does not match". That second failure must not be
        # waved away with --ignore-security-hash on a machine that will touch
        # evidence: the error cannot distinguish a stale manifest from a
        # tampered download, and that distinction is the entire point.
        "win32": ("Download Android SDK Platform-Tools directly from "
                  "https://dl.google.com/android/repository/"
                  "platform-tools-latest-windows.zip, unzip it, and add that "
                  "folder to PATH. Avoid the winget package: it frequently "
                  "installs without adding adb to PATH, and its manifest hash "
                  "goes stale (\"Installer hash does not match\"). Do not "
                  "bypass that hash check on a forensic workstation."),
        "darwin": "brew install --cask android-platform-tools",
        "linux": "apt install android-tools-adb  (or: dnf install android-tools)",
    },
    "libimobiledevice": {
        "win32": ("Install iTunes (which provides the Apple Mobile Device "
                  "Service), or build libimobiledevice for Windows. Live iOS "
                  "acquisition on Windows is awkward — importing an existing "
                  "iTunes backup is the reliable route."),
        "darwin": "brew install libimobiledevice",
        "linux": "apt install libimobiledevice-utils  (or: dnf install libimobiledevice-utils)",
    },
}


def _hint(tool: str) -> str:
    """The install instruction for *this* operating system."""
    if sys.platform.startswith("win"):
        key = "win32"
    elif sys.platform == "darwin":
        key = "darwin"
    else:
        key = "linux"
    return INSTALL_HINTS.get(tool, {}).get(key, "")


# Where these tools actually get installed, per platform. `shutil.which` only
# searches PATH, and PATH is read once when the process starts — so an examiner
# who installs adb while ARGUS is open, then presses "Scan again", is told the
# tool is still missing. That reads as the install having failed. Worse, the
# most common Windows install is an unzip to a folder that was never added to
# PATH at all, which no amount of rescanning will ever find.
WELL_KNOWN: Dict[str, Dict[str, List[str]]] = {
    "adb": {
        "win32": [
            r"C:\platform-tools\adb.exe",
            r"C:\Android\platform-tools\adb.exe",
            r"%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe",
            r"%USERPROFILE%\AppData\Local\Android\Sdk\platform-tools\adb.exe",
            r"%ProgramFiles%\Android\platform-tools\adb.exe",
            r"%ProgramFiles(x86)%\Android\android-sdk\platform-tools\adb.exe",
            r"%LOCALAPPDATA%\Microsoft\WinGet\Links\adb.exe",
        ],
        "darwin": [
            "/opt/homebrew/bin/adb", "/usr/local/bin/adb",
            "~/Library/Android/sdk/platform-tools/adb",
        ],
        "linux": [
            "/usr/bin/adb", "/usr/local/bin/adb", "/snap/bin/adb",
            "~/Android/Sdk/platform-tools/adb",
        ],
    },
    "idevice_id": {
        "win32": [
            r"%ProgramFiles%\libimobiledevice\idevice_id.exe",
            r"C:\libimobiledevice\idevice_id.exe",
        ],
        "darwin": ["/opt/homebrew/bin/idevice_id", "/usr/local/bin/idevice_id"],
        "linux": ["/usr/bin/idevice_id", "/usr/local/bin/idevice_id"],
    },
    "ideviceinfo": {
        "win32": [
            r"%ProgramFiles%\libimobiledevice\ideviceinfo.exe",
            r"C:\libimobiledevice\ideviceinfo.exe",
        ],
        "darwin": ["/opt/homebrew/bin/ideviceinfo", "/usr/local/bin/ideviceinfo"],
        "linux": ["/usr/bin/ideviceinfo", "/usr/local/bin/ideviceinfo"],
    },
}


def _platform_key() -> str:
    if sys.platform.startswith("win"):
        return "win32"
    return "darwin" if sys.platform == "darwin" else "linux"


def find_tool(name: str) -> str:
    r"""Locate an executable: PATH first, then the usual install locations.

    Returns the path, or "" if it genuinely is not present. Falling back to
    well-known locations means the common case — unzip platform-tools to
    C:\platform-tools and never touch PATH — simply works, and "Scan again"
    behaves the way its label promises.

    Note the r-prefix: a Windows path in a plain docstring makes ``\p`` an
    invalid escape sequence, which Python 3.12+ warns about on every import and
    will eventually reject outright. It also prints a warning to the examiner's
    console during an otherwise clean run, which does not inspire confidence.
    """
    found = shutil.which(name)
    if found:
        return found
    for candidate in WELL_KNOWN.get(name, {}).get(_platform_key(), []):
        expanded = Path(os.path.expandvars(candidate)).expanduser()
        if "%" in str(expanded):
            continue                      # an unset variable; skip it
        try:
            if expanded.is_file() and os.access(expanded, os.X_OK):
                return str(expanded)
        except OSError:
            continue
    return ""


def _first_line(text: str) -> str:
    """First line of command output, tolerating no output at all."""
    for line in (text or "").splitlines():
        if line.strip():
            return line.strip()
    return ""


def toolchain_status() -> Dict[str, Any]:
    """Report which acquisition toolchains are usable on this workstation."""
    adb = find_tool("adb")
    idev = find_tool("idevice_id")
    ideviceinfo = find_tool("ideviceinfo")
    return {
        "adb": {
            "available": bool(adb), "path": adb,
            # A binary on PATH is not the same as a binary that runs. A broken
            # install, the wrong architecture, or a policy block all produce an
            # executable that returns nothing — and indexing [0] into that empty
            # output crashed device detection outright, on a workstation where
            # the examiner has no way to see why.
            "version": _first_line(_run([adb, "version"])) if adb else "",
            "install_hint": _hint("adb"),
            "needed_for": "Live acquisition from a connected Android handset.",
            "not_needed_for": ("Importing an extraction that already exists on "
                               "disk, which is the usual case."),
        },
        "libimobiledevice": {
            "available": bool(idev and ideviceinfo),
            "path": idev,
            "install_hint": _hint("libimobiledevice"),
            "needed_for": "Live acquisition from a connected iPhone or iPad.",
            "not_needed_for": "Importing an existing iTunes backup folder.",
        },
    }


# --------------------------------------------------------------------- Android
def _adb_props(serial: str, adb: str = "adb") -> Dict[str, str]:
    out = _run([adb, "-s", serial, "shell", "getprop"])
    props: Dict[str, str] = {}
    for line in out.splitlines():
        m = re.match(r"\[([^\]]+)\]:\s*\[(.*)\]", line.strip())
        if m:
            props[m.group(1)] = m.group(2)
    return props


def _adb_imei(serial: str, adb: str = "adb") -> str:
    for cmd in (
        [adb, "-s", serial, "shell", "service", "call", "iphonesubinfo", "1"],
        [adb, "-s", serial, "shell", "dumpsys", "iphonesubinfo"],
    ):
        out = _run(cmd)
        if not out:
            continue
        # `service call` returns UTF-16 chunks inside parcel dumps
        chunks = re.findall(r"'([^']*)'", out)
        digits = "".join(re.sub(r"[^0-9]", "", c) for c in chunks)
        if len(digits) >= 14:
            return digits[:15]
        m = re.search(r"Device ID\s*=\s*(\d{14,16})", out)
        if m:
            return m.group(1)
    return ""


def detect_android() -> List[DetectedDevice]:
    """Every Android handset on the bus, whatever state it is in.

    Three faults lived here, and together they made a connected phone report as
    "no device detected":

    * ``shutil.which`` only searches PATH, so a perfectly good adb sitting in
      ``C:\\platform-tools`` was invisible — while `selfcheck` reported it as
      available, because that used the wider lookup. Two answers to the same
      question, and the scan had the wrong one.
    * Splitting the listing on whitespace turned the state ``no permissions``
      into ``no``, matching nothing.
    * Anything not in state ``device`` was dropped entirely. A handset that is
      plugged in and enumerating, but offline or awaiting authorisation, is not
      "no device" — it is a device with a specific, fixable problem, and hiding
      it sends the examiner to check the cable.

    Devices in every state are now returned, each carrying its adb state and
    what to do about it. Several handsets can be attached at once; each is
    queried by serial, so their properties never cross.
    """
    adb = find_tool("adb")
    if not adb:
        return []

    from .diagnose import STATE_MEANING, parse_devices

    listing = _run([adb, "devices", "-l"])
    devices: List[DetectedDevice] = []

    for entry in parse_devices(listing):
        serial, state = entry.serial, entry.state
        meaning, fix = STATE_MEANING.get(
            state, ("Unrecognised adb state.",
                    "Consult the adb documentation for this state."))

        if state != "device":
            # Reachable but not usable. Report it with the reason rather than
            # pretending nothing is attached.
            devices.append(DetectedDevice(
                transport="adb", serial=serial,
                make=entry.product.split("_")[0] if entry.product else "",
                model=entry.model or "",
                marketing_name=entry.model or serial,
                os_family="Android",
                lock_state="locked" if state == "unauthorized" else "unknown",
                trusted=False,
                raw={"adb_state": state, "ready": False,
                     "meaning": meaning, "hint": fix},
            ))
            continue

        props = _adb_props(serial, adb)
        battery_raw = _run([adb, "-s", serial, "shell", "dumpsys", "battery"])
        m = re.search(r"level:\s*(\d+)", battery_raw)
        rooted = bool(_run([adb, "-s", serial, "shell", "which", "su"]))
        devices.append(DetectedDevice(
            transport="adb", serial=serial,
            make=props.get("ro.product.manufacturer", "") or
                 props.get("ro.product.brand", ""),
            model=props.get("ro.product.model", ""),
            marketing_name=props.get("ro.product.marketname", "") or
                           props.get("ro.product.model", ""),
            os_family="Android",
            os_version=props.get("ro.build.version.release", ""),
            build_id=props.get("ro.build.display.id", "") or
                     props.get("ro.build.id", ""),
            chipset=props.get("ro.board.platform", "") or
                    props.get("ro.hardware", ""),
            imei=_adb_imei(serial, adb),
            lock_state="unlocked",
            rooted=rooted,
            encrypted=props.get("ro.crypto.state", "encrypted") == "encrypted",
            battery=int(m.group(1)) if m else None,
            raw={"adb_state": state, "ready": True,
                 "props": {k: v for k, v in props.items()
                           if k.startswith(("ro.product", "ro.build",
                                            "ro.crypto"))}},
        ))
    return devices


# ------------------------------------------------------------------------ iOS
IOS_MODEL_MAP = {
    "iPhone13,1": "iPhone 12 mini", "iPhone13,2": "iPhone 12",
    "iPhone13,3": "iPhone 12 Pro", "iPhone13,4": "iPhone 12 Pro Max",
    "iPhone14,5": "iPhone 13", "iPhone14,2": "iPhone 13 Pro",
    "iPhone14,7": "iPhone 14", "iPhone15,2": "iPhone 14 Pro",
    "iPhone15,4": "iPhone 15", "iPhone16,1": "iPhone 15 Pro",
}


def detect_ios() -> List[DetectedDevice]:
    idevice_id = find_tool("idevice_id")
    ideviceinfo = find_tool("ideviceinfo")
    if not (idevice_id and ideviceinfo):
        return []
    udids = [u.strip() for u in _run([idevice_id, "-l"]).splitlines() if u.strip()]
    devices: List[DetectedDevice] = []
    for udid in udids:
        raw = _run([ideviceinfo, "-u", udid])
        info: Dict[str, str] = {}
        for line in raw.splitlines():
            if ": " in line:
                k, v = line.split(": ", 1)
                info[k.strip()] = v.strip()
        if not info:
            devices.append(DetectedDevice(
                transport="usbmux", serial=udid, make="Apple",
                os_family="iOS", trusted=False, lock_state="locked",
                raw={"hint": "Device is not paired — tap 'Trust' on the handset."}))
            continue
        product_type = info.get("ProductType", "")
        devices.append(DetectedDevice(
            transport="usbmux", serial=udid, make="Apple",
            model=product_type,
            marketing_name=IOS_MODEL_MAP.get(product_type,
                                             info.get("DeviceName", product_type)),
            os_family="iOS", os_version=info.get("ProductVersion", ""),
            build_id=info.get("BuildVersion", ""),
            chipset=info.get("HardwarePlatform", ""),
            imei=info.get("InternationalMobileEquipmentIdentity", ""),
            iccid=info.get("IntegratedCircuitCardIdentity", ""),
            phone_number=info.get("PhoneNumber", ""),
            lock_state="unlocked" if info.get("PasswordProtected") != "true"
                       else "afu",
            trusted=True,
            encrypted=True,
            raw={"ideviceinfo": info},
        ))
    return devices


# ------------------------------------------------------------------ public API
def detect_all() -> Dict[str, Any]:
    """Step 7: auto-detect connected devices."""
    android, ios = detect_android(), detect_ios()
    tools = toolchain_status()
    devices = android + ios
    diagnostics: List[str] = []
    if not devices:
        # Ask the operating system what is physically attached, independently
        # of whether any forensic tool can talk to it. Telling an examiner "no
        # device detected" while a phone sits plugged into the machine is the
        # tool contradicting the evidence of their own eyes — and it sends them
        # hunting for a broken cable when the cable is fine.
        try:
            from .bus import mobile_devices_on_bus, fastboot_devices, volumes
            on_bus = mobile_devices_on_bus()
            in_fastboot = fastboot_devices()
            evidence_volumes = [v for v in volumes() if v.looks_like_evidence]
        except Exception:                                 # pragma: no cover
            on_bus, in_fastboot, evidence_volumes = [], [], []

        if on_bus:
            names = ", ".join(sorted({d.vendor for d in on_bus}))
            diagnostics.append(
                f"USB reports hardware from {names} attached to this machine, "
                f"so the cable and port are working. The handset is present "
                f"but not answering — the problem is USB debugging, the "
                f"connection mode, or the driver, not the physical link.")
            for device in on_bus:
                if device.mode_note:
                    diagnostics.append(f"{device.vendor}: {device.mode_note}")

        if in_fastboot:
            diagnostics.append(
                f"{len(in_fastboot)} handset(s) are in bootloader/fastboot "
                f"mode, where adb does not operate. Reboot to the system for a "
                f"logical acquisition.")

        if evidence_volumes:
            paths = ", ".join(v.path for v in evidence_volumes[:4])
            diagnostics.append(
                f"Mounted volume(s) containing handset or memory-card "
                f"directories: {paths}. These can be imported directly with no "
                f"adb involved.")

        missing = [name for name in ("adb", "libimobiledevice")
                   if not tools[name]["available"]]
        for name in missing:
            family = "Android" if name == "adb" else "iOS"
            diagnostics.append(
                f"{name} is not installed, so a connected {family} handset "
                f"cannot be detected. To install: "
                f"{tools[name]['install_hint']}")

        if len(missing) < 2:
            diagnostics.append(
                "Toolchain present but no handset responded. Check the data "
                "cable (a charge-only cable will not enumerate), confirm USB "
                "debugging / pairing, and confirm the device is powered on.")

        # Appended once, whichever branch above ran. An examiner who reads
        # "not installed" and stops has been blocked by a message rather than
        # by the tool — and repeating the same sentence twice in one panel is
        # how guidance starts reading as boilerplate and gets skimmed past.
        diagnostics.append(
            "Neither tool is required to import an extraction that already "
            "exists on disk — a folder pulled from the device, an iTunes "
            "backup, a UFDR, a .tar or a .zip. Choose Import on the next step. "
            "Live acquisition is the only thing they unlock.")

    return {
        "devices": [d.as_dict() for d in devices],
        "count": len(devices),
        "toolchain": tools,
        "diagnostics": diagnostics,
    }


def require_device(serial: Optional[str] = None) -> DetectedDevice:
    """Resolve exactly one connected device or explain what is wrong."""
    found = detect_android() + detect_ios()
    if serial:
        for d in found:
            if d.serial == serial:
                return d
        raise AcquisitionError(f"device with serial {serial!r} is not connected")
    if not found:
        raise AcquisitionError(
            "no device detected. " + " ".join(detect_all()["diagnostics"]))
    if len(found) > 1:
        names = ", ".join(f"{d.serial} ({d.name})" for d in found)
        raise AcquisitionError(
            f"{len(found)} devices connected; specify one with --serial: {names}")
    return found[0]
