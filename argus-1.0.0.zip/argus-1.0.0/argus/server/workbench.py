"""ARGUS Workbench — the single-click application server.

Serves one browser app that carries an examiner through the entire lab manual:
verify device support, create the case, register the exhibit, run the
extraction while watching the live log, then analyse the result and export the
report. No command line, no separate analysis step.

Still standard library only. A forensic workstation is frequently locked down
or air-gapped, and an application that cannot start without a package index is
an application that cannot be used when it matters.

Security posture
----------------
* Binds to ``127.0.0.1`` only, and mints a random session token at start-up.
  Every API call must carry it. Without this, any web page open in the same
  browser could drive an examiner's forensic tool through localhost.
* Directory browsing is read-only and returns names and sizes, never contents.
* Sealed evidence has no write path. Acquisition writes only into the case
  folder chosen by the operator.
* No upload endpoint, no shell surface, no eval.
"""

from __future__ import annotations

import json
import mimetypes
import os
import platform
import secrets
import socket
import string
import sys
import threading
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import parse_qs, unquote, urlparse

from .. import __version__
from ..analyze.session import AnalysisSession
from ..core.case import Case, Exhibit, discover_cases, generate_case_id
from ..core.container import EvidenceContainer
from ..core.errors import ArgusError
from ..core.models import Category
from ..devices.detect import detect_all, toolchain_status
from ..devices.manual import DeviceManual, LOCK_STATES
from .jobs import Job, JobRunner

UI_DIR = Path(__file__).resolve().parent.parent / "ui"
WORKBENCH_HTML = UI_DIR / "workbench.html"
XAMN_HTML = UI_DIR / "xamn.html"

ALL_CATEGORIES = [c.value for c in Category]


# ---------------------------------------------------------------- app state
class Workbench:
    """Shared state for the running application."""

    def __init__(self, workspace: Path, token: str):
        self.workspace = Path(workspace).expanduser().resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.token = token
        self.manual = DeviceManual()
        self.jobs = JobRunner()
        self._sessions: Dict[str, AnalysisSession] = {}
        self._lock = threading.Lock()
        self.started_at = datetime.now(timezone.utc).isoformat(timespec="seconds")

    # ------------------------------------------------------- analysis cache
    def session_for(self, containers: List[str],
                    deep_verify: bool = False) -> AnalysisSession:
        """Open (or reuse) a read-only analysis session for these containers."""
        key = "|".join(sorted(str(Path(c).resolve()) for c in containers))
        with self._lock:
            existing = self._sessions.get(key)
            if existing is not None:
                return existing
        session = AnalysisSession([Path(c) for c in containers],
                                  deep_verify=deep_verify)
        with self._lock:
            self._sessions[key] = session
        return session

    def drop_session(self, containers: List[str]) -> None:
        key = "|".join(sorted(str(Path(c).resolve()) for c in containers))
        with self._lock:
            session = self._sessions.pop(key, None)
        if session:
            session.close()

    def close(self) -> None:
        with self._lock:
            sessions = list(self._sessions.values())
            self._sessions.clear()
        for s in sessions:
            try:
                s.close()
            except Exception:
                pass


# ------------------------------------------------------------------ helpers
def _drives() -> List[str]:
    """Enumerate root locations to offer in the folder picker."""
    roots: List[str] = []
    if os.name == "nt":
        for letter in string.ascii_uppercase:
            path = f"{letter}:\\"
            if os.path.exists(path):
                roots.append(path)
    else:
        roots.append("/")
    home = str(Path.home())
    for candidate in (home, str(Path(home) / "Desktop"),
                      str(Path(home) / "Documents"),
                      str(Path(home) / "Downloads")):
        if os.path.isdir(candidate) and candidate not in roots:
            roots.append(candidate)
    return roots


def _browse(path: str) -> Dict[str, Any]:
    """List a directory. Read-only: names, sizes and types, never contents."""
    if not path:
        return {"path": "", "parent": "", "roots": _drives(),
                "dirs": [], "files": [], "is_root_list": True}
    target = Path(path).expanduser()
    try:
        target = target.resolve()
    except OSError:
        pass
    if not target.exists():
        raise ArgusError(f"path does not exist: {target}")
    if not target.is_dir():
        target = target.parent

    dirs, files = [], []
    try:
        for entry in sorted(os.scandir(target), key=lambda e: e.name.lower()):
            try:
                if entry.is_dir(follow_symlinks=False):
                    marker = ""
                    if entry.name.endswith(".afc"):
                        marker = "container"
                    elif os.path.exists(os.path.join(entry.path, "case.json")):
                        marker = "case"
                    elif os.path.exists(os.path.join(entry.path, "Manifest.db")):
                        marker = "ios-backup"
                    dirs.append({"name": entry.name, "path": entry.path,
                                 "kind": marker})
                elif entry.is_file(follow_symlinks=False):
                    size = entry.stat().st_size
                    files.append({"name": entry.name, "path": entry.path,
                                  "size": size,
                                  "kind": "backup" if entry.name.lower()
                                          .endswith(".ab") else "file"})
            except OSError:
                continue
    except PermissionError as exc:
        raise ArgusError(f"cannot read {target}: {exc}") from exc

    return {
        "path": str(target),
        "parent": str(target.parent) if target.parent != target else "",
        "roots": _drives(),
        "dirs": dirs,
        "files": files[:600],
        "is_root_list": False,
    }


def _classify_source(path: str) -> Dict[str, Any]:
    """Tell the operator what they just pointed at, before they commit to it."""
    p = Path(path).expanduser()
    if not p.exists():
        return {"ok": False, "kind": "missing",
                "detail": "That path does not exist."}
    if p.is_file():
        if p.suffix.lower() == ".ab":
            return {"ok": True, "kind": "android-backup",
                    "detail": "Android adb backup archive (.ab). If it is "
                              "AES-encrypted you will need the backup password."}
        return {"ok": True, "kind": "file",
                "detail": f"Single file ({p.suffix or 'no extension'}). It will "
                          f"be parsed if a parser recognises it."}
    if (p / "Manifest.db").exists():
        try:
            from ..acquire.ios_backup import IOSBackup
            backup = IOSBackup(p)
            info = backup.device_info()
            return {
                "ok": True, "kind": "ios-backup",
                "detail": (f"iOS backup — {info.get('device_name') or 'unnamed'} "
                           f"{info.get('product_type')} iOS "
                           f"{info.get('product_version')}"),
                "encrypted": backup.encrypted,
                "device": info,
                "warning": ("This backup is encrypted. Produce an unencrypted "
                            "backup, or supply the password."
                            if backup.encrypted else ""),
            }
        except Exception as exc:
            return {"ok": True, "kind": "ios-backup",
                    "detail": f"iOS backup folder (could not read header: {exc})"}

    markers = {"android": ["data/data", "sdcard", "system/build.prop",
                           "data/system/packages.list"],
               "ios": ["HomeDomain", "CameraRollDomain", "MediaDomain"]}
    hits = {k: sum(1 for m in v if (p / m).exists()) for k, v in markers.items()}
    files = sum(1 for _ in p.rglob("*") if _.is_file())
    if hits["android"] > hits["ios"] and hits["android"]:
        kind, detail = "android-tree", "Android file-system tree"
    elif hits["ios"]:
        kind, detail = "ios-tree", "iOS logical file tree"
    else:
        kind, detail = "folder", "Folder — platform not recognised from layout"
    return {"ok": True, "kind": kind,
            "detail": f"{detail} · {files:,} files", "files": files}


def _human(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} PB"


# ----------------------------------------------------------------- handler
class _Handler(BaseHTTPRequestHandler):
    wb: Workbench
    server_version = f"ARGUS-Workbench/{__version__}"
    protocol_version = "HTTP/1.1"

    # ------------------------------------------------------------ responses
    def _send(self, code: int, body: bytes, ctype: str,
              extra: Optional[Dict[str, str]] = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _json(self, payload: Any, code: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        self._send(code, body, "application/json; charset=utf-8")

    def _error(self, code: int, message: str, **extra: Any) -> None:
        self._json({"error": message, "status": code, **extra}, code)

    def log_message(self, fmt: str, *args) -> None:
        return

    # ------------------------------------------------------------------ auth
    def _authorised(self, query: Dict[str, str]) -> bool:
        token = (query.get("token")
                 or self.headers.get("X-ARGUS-Token", ""))
        return secrets.compare_digest(str(token), self.wb.token)

    # ------------------------------------------------------------------- GET
    def do_GET(self) -> None:                                # noqa: N802
        parsed = urlparse(self.path)
        route = unquote(parsed.path)
        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        try:
            if route in ("/", "/index.html"):
                return self._serve_file(WORKBENCH_HTML, "text/html")
            if route == "/xamn.html":
                return self._serve_file(XAMN_HTML, "text/html")
            if route == "/api/ping":
                return self._json({"ok": True, "version": __version__})

            if route.startswith("/api/") or route.startswith("/blob/"):
                if not self._authorised(query):
                    return self._error(401, "invalid or missing session token")
            if route.startswith("/blob/"):
                return self._serve_blob(route[6:], query)
            if route.startswith("/api/"):
                return self._api_get(route[5:].strip("/"), query)
            return self._error(404, f"no such route: {route}")
        except ArgusError as exc:
            return self._error(400, str(exc))
        except Exception as exc:
            return self._error(500, f"{type(exc).__name__}: {exc}")

    do_HEAD = do_GET

    def _serve_file(self, path: Path, ctype: str) -> None:
        if not path.exists():
            return self._error(500, f"UI asset missing: {path.name}")
        self._send(200, path.read_bytes(), f"{ctype}; charset=utf-8")

    def _serve_blob(self, sha: str, query: Dict[str, str]) -> None:
        sha = sha.split("/")[0].split("?")[0]
        if len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha):
            return self._error(400, "invalid blob identifier")
        containers = _containers_arg(query)
        if not containers:
            return self._error(400, "no container specified")
        session = self.wb.session_for(containers)
        got = session.blob(sha)
        if got is None:
            return self._error(404, "blob not present in the loaded containers")
        data, mime = got
        self._send(200, data, mime or "application/octet-stream",
                   {"Content-Disposition": f'inline; filename="{sha[:16]}"'})

    # ------------------------------------------------------------- GET API
    def _api_get(self, endpoint: str, q: Dict[str, str]) -> None:
        wb = self.wb
        i = lambda k, d: int(q.get(k, d))                     # noqa: E731

        # ---- environment ------------------------------------------------
        if endpoint == "env":
            return self._json({
                "version": __version__,
                # The build ID belongs in the UI, not just in `selfcheck`. An
                # examiner with several extracted copies on different drives
                # has no way to tell from the screen which one is running, and
                # will troubleshoot a fixed bug in a stale folder for as long
                # as it takes someone to ask which build it is.
                "build": _installation_id(),
                "python": sys.version.split()[0],
                "platform": platform.platform(),
                "workspace": str(wb.workspace),
                "started_at": wb.started_at,
                "toolchain": toolchain_status(),
                "categories": ALL_CATEGORIES,
                "lock_states": list(LOCK_STATES),
                "capabilities": _feature_report(),
                "suggested_case_id": generate_case_id(),
            })

        if endpoint == "browse":
            return self._json(_browse(q.get("path", "")))

        if endpoint == "classify":
            return self._json(_classify_source(q.get("path", "")))

        # ---- device manual ----------------------------------------------
        if endpoint == "diagnose":
            from ..devices.diagnose import diagnose, vendor_guidance_for
            report = diagnose()
            data = report.as_dict()
            make = q.get("make", "")
            if make and not data["vendor_guidance"]:
                data["vendor_guidance"] = vendor_guidance_for(make)
            return self._json(data)

        if endpoint == "devices":
            return self._json(detect_all())

        if endpoint == "manual/search":
            hits = wb.manual.search(q.get("q", ""), limit=i("limit", 12))
            return self._json({"results": [p.as_dict() for p in hits]})

        if endpoint == "manual/show":
            return self._json(wb.manual.overview(q.get("q", "")))

        # ---- cases -------------------------------------------------------
        if endpoint == "cases":
            base = q.get("dir") or str(wb.workspace / "cases")
            return self._json({"dir": base, "cases": discover_cases(base)})

        if endpoint == "case":
            case = Case.open(q.get("path", ""), password=q.get("password") or None)
            return self._json(case.overview())

        if endpoint == "containers":
            case = Case.open(q.get("path", ""), password=q.get("password") or None)
            return self._json({"containers": [str(p) for p in case.containers()]})

        # ---- jobs --------------------------------------------------------
        if endpoint == "job":
            job = wb.jobs.get(q.get("id", ""))
            if job is None:
                return self._error(404, "no such job")
            return self._json(job.snapshot(since=i("since", 0)))

        if endpoint == "jobs":
            return self._json({"jobs": wb.jobs.recent(i("limit", 20))})

        # ---- verification -------------------------------------------------
        if endpoint == "verify":
            containers = _containers_arg(q)
            out = []
            for c in containers:
                container = EvidenceContainer(Path(c), mode="r")
                try:
                    out.append({"container": Path(c).name,
                                **container.verify(deep=q.get("deep") == "1")})
                finally:
                    container.close()
            return self._json({"results": out,
                               "ok": all(r["ok"] for r in out)})

        # ---- analysis (delegated to AnalysisSession) ----------------------
        containers = _containers_arg(q)
        if not containers:
            return self._error(400,
                               f"endpoint '{endpoint}' requires ?containers=")
        s = wb.session_for(containers)
        routes: Dict[str, Callable[[], Any]] = {
            "overview":     lambda: s.overview(),
            "search":       lambda: s.query(q.get("q", ""), i("limit", 200),
                                            i("offset", 0),
                                            q.get("order", "timestamp DESC")),
            "artifact":     lambda: s.get(q.get("id", "")) or {"error": "not found"},
            "gallery":      lambda: s.gallery(only_images=q.get("images") == "1",
                                              with_gps=q.get("gps") == "1",
                                              app=q.get("app", ""),
                                              limit=i("limit", 300),
                                              offset=i("offset", 0)),
            "connections":  lambda: s.connections(q.get("scope", "all"),
                                                  i("min_weight", 1),
                                                  i("max_nodes", 300)),
            "applications": lambda: s.applications(),
            "application":  lambda: s.application(q.get("app", ""), i("limit", 300)),
            "column":       lambda: s.column_view(q.get("category", "Contacts"),
                                                  i("limit", 2000)),
            "timeline":     lambda: s.timeline(q.get("q", ""), i("limit", 5000)),
            "statistics":   lambda: s.statistics(q.get("q", "")),
            "places":       lambda: s.places(),
            "deleted":      lambda: s.deleted(i("limit", 500)),
            "log":          lambda: s.extraction_log(),
            "audit":        lambda: s.audit_trail(),
            "integrity":    lambda: s.integrity_report(),
            "intelligence": lambda: s.intelligence(
                [x.strip() for x in q.get("owner", "").split(",") if x.strip()]),
        }
        fn = routes.get(endpoint)
        if fn is None:
            return self._error(404, f"unknown endpoint '{endpoint}'")
        return self._json(fn())

    # ------------------------------------------------------------------ POST
    def do_POST(self) -> None:                               # noqa: N802
        parsed = urlparse(self.path)
        route = unquote(parsed.path)
        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            return self._error(400, "request body is not valid JSON")
        if not self._authorised({**query, "token": payload.get("token", "")}):
            return self._error(401, "invalid or missing session token")

        try:
            return self._api_post(route[5:].strip("/"), payload)
        except ArgusError as exc:
            return self._error(400, str(exc))
        except Exception as exc:
            return self._error(500, f"{type(exc).__name__}: {exc}")

    def _api_post(self, endpoint: str, body: Dict[str, Any]) -> None:
        wb = self.wb

        # ---- Steps 3–5: create the case ---------------------------------
        if endpoint == "case/new":
            base = body.get("dir") or str(wb.workspace / "cases")
            case = Case.create(
                base, case_id=body.get("case_id") or None,
                investigator=body.get("investigator", ""),
                organisation=body.get("organisation", ""),
                description=body.get("description", ""),
                password=body.get("password") or None)
            return self._json({"ok": True, "case_id": case.case_id,
                               "path": str(case.root),
                               "overview": case.overview()})

        # ---- register the exhibit ---------------------------------------
        if endpoint == "exhibit/add":
            case = Case.open(body["case_path"],
                             password=body.get("password") or None)
            exhibit = case.add_exhibit(Exhibit(
                exhibit_id=body["exhibit_id"],
                description=body.get("description", ""),
                make=body.get("make", ""), model=body.get("model", ""),
                imei=body.get("imei", ""), serial=body.get("serial", ""),
                phone_number=body.get("phone_number", ""),
                seized_at=body.get("seized_at", ""),
                seized_by=body.get("seized_by", ""),
                seized_from=body.get("seized_from", ""),
                condition=body.get("condition", ""),
                isolation=body.get("isolation", "")))
            warnings = []
            if not exhibit.isolation:
                warnings.append(
                    "No isolation method recorded. Manual §7 precaution 2: "
                    "place the device in airplane mode or a Faraday pouch to "
                    "prevent a remote wipe.")
            return self._json({"ok": True, "exhibit": exhibit.as_dict(),
                               "warnings": warnings,
                               "overview": case.overview()})

        # ---- Steps 8–13: run the extraction ------------------------------
        if endpoint == "acquire":
            return self._json(self._start_acquisition(body))

        if endpoint == "validate":
            return self._json(self._start_validation(body))

        if endpoint == "certificate":
            return self._json(self._start_certificate(body))

        if endpoint == "job/cancel":
            job = wb.jobs.get(body.get("id", ""))
            if job is None:
                return self._error(404, "no such job")
            job.request_cancel()
            return self._json({"ok": True})

        # ---- Step 21: report ---------------------------------------------
        if endpoint == "report":
            return self._json(self._start_report(body))

        # ---- tagging -------------------------------------------------------
        if endpoint == "tag":
            session = wb.session_for(body.get("containers", []))
            ok = session.tag(body.get("artifact_id", ""), body.get("name", ""),
                             body.get("colour", "#e2b33c"),
                             body.get("note", ""), body.get("actor", "analyst"))
            return self._json({"ok": ok})

        return self._error(404, f"no such route: /api/{endpoint}")

    # ------------------------------------------------- acquisition plumbing
    def _start_acquisition(self, body: Dict[str, Any]) -> Dict[str, Any]:
        from ..acquire.engine import AcquisitionEngine, AcquisitionPlan
        from ..devices.detect import require_device

        wb = self.wb
        case = Case.open(body["case_path"], password=body.get("password") or None)
        categories = body.get("categories") or ALL_CATEGORIES
        method = body.get("method", "import")

        plan = AcquisitionPlan(
            method=method,
            time_span=body.get("time_span", "all"),
            categories=list(categories),
            operator=body.get("operator", ""),
            exhibit_id=body.get("exhibit_id", ""),
            lock_state=body.get("lock_state", "unlocked"),
            device_name=body.get("device_name", ""),
            serial=body.get("serial") or None,
            source_path=Path(body["source_path"]) if body.get("source_path") else None,
            backup_password=body.get("backup_password") or None,
            recover_deleted=bool(body.get("recover_deleted", True)),
            carve_confidence=float(body.get("carve_confidence", 0.45)),
            owner_identifiers=[s.strip() for s in
                               str(body.get("owner", "")).split(",") if s.strip()],
            owner_name=body.get("owner_name", "Device owner"),
            notes=body.get("notes", ""))
        plan.validate()

        # Fail fast, in the browser, before a job is spawned — an operator
        # should learn that a method is unsupported now, not from a log line
        # thirty seconds into an extraction.
        if plan.device_name and method != "import":
            wb.manual.assert_supported(plan.device_name, plan.lock_state, method)

        device = None
        if method != "import":
            device = require_device(plan.serial)
        elif not plan.source_path or not plan.source_path.exists():
            raise ArgusError("choose an evidence folder or backup file to import")

        label = f"{plan.exhibit_id} · {method}"

        def work(job: Job) -> Dict[str, Any]:
            engine = AcquisitionEngine(
                case, manual=wb.manual,
                progress=lambda entry: job.emit(
                    entry.get("module", ""), entry.get("status", ""),
                    entry.get("message", ""), entry.get("level", "info")))
            job.emit("job", "start", f"Extraction queued — {label}")
            report = engine.run(plan, device=device)
            return report.as_dict()

        job = wb.jobs.submit("acquire", work, label=label)
        return {"ok": True, "job_id": job.id, "label": label}

    def _start_validation(self, body: Dict[str, Any]) -> Dict[str, Any]:
        from ..validate.harness import run_validation
        wb = self.wb
        out_dir = Path(body.get("out_dir") or (wb.workspace / "validation"))

        def work(job: Job) -> Dict[str, Any]:
            job.emit("validate", "start",
                     "Building reference corpus with known ground truth")
            report = run_validation(
                progress=lambda m: job.emit("validate", "running", m))
            data = report.as_dict()
            out_dir.mkdir(parents=True, exist_ok=True)
            target = out_dir / "validation_report.json"
            target.write_text(json.dumps(data, indent=2, default=str),
                              encoding="utf-8")
            summary = data["summary"]
            job.emit("validate", "ok",
                     f"{summary['tests_passed']}/{summary['tests_run']} tests "
                     f"passed · recall {summary['overall_recall']} · precision "
                     f"{summary['overall_precision']}")
            for cap, m in data["by_capability"].items():
                job.emit("validate", "result",
                         f"{cap}: recall={m['recall']} precision={m['precision']}"
                         f" ({m['passed']}/{m['tests']} passed)")
            data["report_path"] = str(target)
            return data

        job = wb.jobs.submit("validate", work, label="tool validation")
        return {"ok": True, "job_id": job.id}

    def _start_certificate(self, body: Dict[str, Any]) -> Dict[str, Any]:
        from ..validate.certificate import (ExaminerNote, build_certificate,
                                            generate_key, write_certificate)
        wb = self.wb
        containers = body.get("containers") or []
        if not containers:
            raise ArgusError("no containers selected for the certificate")
        out_dir = Path(body.get("out_dir") or (wb.workspace / "certificates"))

        def work(job: Job) -> Dict[str, Any]:
            job.emit("certificate", "start",
                     f"Re-hashing every blob in {len(containers)} container(s)")
            validation = None
            vpath = body.get("validation_path")
            if vpath and Path(vpath).exists():
                validation = json.loads(Path(vpath).read_text())
                job.emit("certificate", "ok", "validation report attached")
            notes = [ExaminerNote(author=body.get("examiner") or "examiner",
                                  text=n)
                     for n in (body.get("notes") or []) if n]
            key = generate_key() if body.get("seal") else None
            cert = build_certificate(
                [Path(c) for c in containers],
                examiner=body.get("examiner", ""),
                organisation=body.get("organisation", ""),
                reference=body.get("reference", ""),
                notes=notes, validation=validation,
                peer_reviewer=body.get("peer_reviewer", ""), key=key)
            target = write_certificate(
                cert, out_dir / (body.get("basename") or "certificate.json"))
            result = {"path": str(target),
                      "digest": cert["certificate_sha256"],
                      "all_verified": cert["all_containers_verified"],
                      "containers": len(cert["containers"]),
                      "validation_attached": cert["validation"]["performed"]}
            if key:
                key_path = Path(str(target) + ".key")
                key_path.write_text(key.hex(), encoding="utf-8")
                result["key_path"] = str(key_path)
                job.emit("certificate", "warning",
                         "Seal key written alongside the certificate. Move it "
                         "to separate storage — anyone holding it can re-seal "
                         "an altered certificate.", level="warning")
            job.emit("certificate", "ok" if cert["all_containers_verified"]
                     else "error",
                     f"Certificate issued: {target.name}"
                     + ("" if cert["all_containers_verified"]
                        else " — WITH VERIFICATION FAILURES recorded"),
                     level="info" if cert["all_containers_verified"] else "error")
            return result

        job = wb.jobs.submit("certificate", work,
                             label=f"{len(containers)} container(s)")
        return {"ok": True, "job_id": job.id}

    def _start_report(self, body: Dict[str, Any]) -> Dict[str, Any]:
        from ..report.builder import ReportBuilder, ReportOptions

        wb = self.wb
        containers = body.get("containers") or []
        if not containers:
            raise ArgusError("no containers selected for the report")
        out_dir = Path(body.get("out_dir") or (wb.workspace / "reports"))
        formats = body.get("formats") or ["html"]

        opts = ReportOptions(
            title=body.get("title") or "Mobile Device Forensic Examination Report",
            scope=body.get("scope", "all"),
            query=body.get("query", ""),
            selected_ids=body.get("selected_ids") or [],
            formats=list(formats),
            include_deleted=bool(body.get("include_deleted", True)),
            include_graph=bool(body.get("include_graph", True)),
            include_timeline=bool(body.get("include_timeline", True)),
            include_log=bool(body.get("include_log", False)),
            include_audit=bool(body.get("include_audit", False)),
            include_intelligence=bool(body.get("include_intelligence", True)),
            owner_identifiers=[x.strip() for x in
                               str(body.get("owner", "")).split(",") if x.strip()],
            examiner=body.get("examiner", ""),
            organisation=body.get("organisation", ""),
            reference=body.get("reference", ""),
            conclusion=body.get("conclusion", ""))

        def work(job: Job) -> Dict[str, Any]:
            job.emit("report", "start",
                     f"Verifying {len(containers)} container(s) before export")
            with AnalysisSession([Path(c) for c in containers],
                                 deep_verify=True) as session:
                if not session.integrity_ok:
                    job.emit("report", "warning",
                             "Integrity verification FAILED — the report will "
                             "carry a prominent warning on its first page.",
                             level="warning")
                else:
                    job.emit("report", "ok", "Integrity verified")
                builder = ReportBuilder(session, opts)
                job.emit("report", "building",
                         f"{builder.data['artifact_count']:,} artifacts "
                         f"({builder.data['deleted_count']:,} recovered from "
                         f"deleted space)")
                written = builder.write(out_dir, body.get("basename")
                                        or "forensic_report")
                for p in written:
                    job.emit("report", "ok",
                             f"{p.name} — {_human(p.stat().st_size)}")
                return {
                    "files": [{"path": str(p), "name": p.name,
                               "size": p.stat().st_size} for p in written],
                    "artifact_count": builder.data["artifact_count"],
                    "deleted_count": builder.data["deleted_count"],
                    "out_dir": str(out_dir),
                    "integrity_ok": session.integrity_ok,
                }

        job = wb.jobs.submit("report", work,
                             label=f"{len(containers)} container(s)")
        return {"ok": True, "job_id": job.id}


def _containers_arg(q: Dict[str, str]) -> List[str]:
    raw = q.get("containers") or q.get("container") or ""
    return [c for c in raw.split("\n") if c.strip()] if "\n" in raw else \
           ([raw] if raw else [])


def _installation_id() -> str:
    """Short build identifier, or "" if it cannot be determined."""
    try:
        from ..core.selfcheck import installation_id
        return installation_id()[:12]
    except Exception:                                     # pragma: no cover
        return ""


def _feature_report() -> Dict[str, Any]:
    """What optional capabilities are actually available in this install."""
    def has(mod: str) -> bool:
        try:
            __import__(mod)
            return True
        except ImportError:
            return False
    return {
        "exif": {"available": has("PIL"), "provides": "EXIF and GPS from images",
                 "install": "pip install pillow"},
        "xlsx": {"available": has("openpyxl"), "provides": "Excel export",
                 "install": "pip install openpyxl"},
        "docx": {"available": has("docx"), "provides": "Word export",
                 "install": "pip install python-docx"},
        "pdf": {"available": has("reportlab"), "provides": "PDF export",
                "install": "pip install reportlab"},
        "encrypted_backup": {"available": has("Crypto"),
                             "provides": "encrypted Android .ab backups",
                             "install": "pip install pycryptodome"},
    }


# --------------------------------------------------------------------- serve
def _free_port(preferred: int) -> int:
    for candidate in (preferred, 0):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind(("127.0.0.1", candidate))
                return sock.getsockname()[1]
            except OSError:
                continue
    return preferred


def serve(workspace: Path | str = "~/ARGUS", port: int = 8742,
          open_browser: bool = True, quiet: bool = False) -> None:
    """Start the workbench application (blocking)."""
    token = secrets.token_urlsafe(24)
    wb = Workbench(Path(workspace), token)
    _Handler.wb = wb
    port = _free_port(port)
    httpd = ThreadingHTTPServer(("127.0.0.1", port), _Handler)
    url = f"http://127.0.0.1:{port}/#token={token}"

    if not quiet:
        features = _feature_report()
        missing = [f"{k} ({v['install']})" for k, v in features.items()
                   if not v["available"]]
        print()
        print("   ARGUS Forensics — Workbench")
        print("   " + "─" * 60)
        print(f"   Version     {__version__}   Python {sys.version.split()[0]}")
        print(f"   Workspace   {wb.workspace}")
        tools = toolchain_status()
        print(f"   adb         {'found' if tools['adb']['available'] else 'not installed (Android live acquisition unavailable)'}")
        print(f"   iOS tools   {'found' if tools['libimobiledevice']['available'] else 'not installed (iOS live acquisition unavailable)'}")
        if missing:
            print(f"   Optional    missing: {', '.join(missing)}")
        print("   " + "─" * 60)
        print(f"   Open  {url}")
        print("   Close this window to stop the application.")
        print()

    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        if not quiet:
            print("\n   Shutting down.")
    finally:
        httpd.server_close()
        wb.close()
