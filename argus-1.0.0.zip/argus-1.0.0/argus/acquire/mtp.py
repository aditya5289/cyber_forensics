"""Acquiring from a handset that is browsable but not debuggable.

A phone in file-transfer mode is mounted, visible, and full of evidence, while
adb sees nothing because USB debugging was never enabled. The standard advice is
to drag the folder out in Explorer, and it works — but it produces no hashes, no
record of what was taken, and no record of what was *missed*. Explorer silently
skips files it cannot read and reports a count nobody writes down.

That last point is the reason this module exists. MTP transfers fail
individually and quietly: a file locked by the phone, a name the host filesystem
rejects, a media provider that lists an entry it will not serve. An examiner who
copies 4,000 files and receives 3,960 has no way to know unless something counts
them. Concluding a photograph was absent when the copy dropped it is exactly the
kind of error that survives all the way into a report.

So every file is hashed as it lands, every failure is recorded with its reason,
and the manifest states plainly what this is: a copy through the handset's own
media provider, not an image of its storage. MTP shows what the provider
chooses to expose. It cannot reach ``/data/data``, and absence here is never
evidence that the device did not hold something.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# Windows exposes MTP through the shell namespace rather than a drive letter, so
# ordinary file APIs cannot reach it. The Shell.Application COM object is the
# route every file manager uses, and it is available on any Windows install
# without extra software — which matters on a locked-down workstation.
_ENUMERATE_DEVICES = r"""
$shell = New-Object -ComObject Shell.Application
$pc = $shell.NameSpace(17)
if ($pc -ne $null) {
  foreach ($item in $pc.Items()) {
    if ($item.IsFolder -and -not $item.Path.EndsWith(':\')) {
      Write-Output ("{0}|{1}" -f $item.Name, $item.Path)
    }
  }
}
"""

_LIST_TREE = r"""
$ErrorActionPreference = 'SilentlyContinue'
$shell = New-Object -ComObject Shell.Application

function Walk($folder, $prefix, $depth) {
  if ($depth -gt __MAXDEPTH__) { return }
  foreach ($item in $folder.Items()) {
    $rel = if ($prefix) { "$prefix/$($item.Name)" } else { $item.Name }
    if ($item.IsFolder) {
      Write-Output ("D|$rel|0")
      Walk $item.GetFolder $rel ($depth + 1)
    } else {
      Write-Output ("F|$rel|$($item.ExtendedProperty('System.Size'))")
    }
  }
}

$device = $null
foreach ($item in $shell.NameSpace(17).Items()) {
  if ($item.Name -eq '__DEVICE__') { $device = $item.GetFolder }
}
if ($device -ne $null) { Walk $device '' 0 }
"""

_COPY_TREE = r"""
$ErrorActionPreference = 'SilentlyContinue'
$shell = New-Object -ComObject Shell.Application
$dest = $shell.NameSpace('__DEST__')

$device = $null
foreach ($item in $shell.NameSpace(17).Items()) {
  if ($item.Name -eq '__DEVICE__') { $device = $item.GetFolder }
}
if ($device -eq $null) { Write-Output 'ERR|device not found'; exit 1 }

foreach ($item in $device.Items()) {
  Write-Output ("COPY|$($item.Name)")
  # 16 = respond yes to all, 512 = no progress dialog, 1024 = no error UI.
  $dest.CopyHere($item, 16 -bor 512 -bor 1024)
}
Write-Output 'DONE'
"""


@dataclass
class MTPDevice:
    """A handset visible in the shell namespace."""

    name: str
    path: str = ""

    def as_dict(self) -> Dict[str, str]:
        return {"name": self.name, "path": self.path}


@dataclass
class AcquisitionResult:
    """What was taken, and — just as importantly — what was not."""

    device: str = ""
    destination: str = ""
    files_copied: int = 0
    bytes_copied: int = 0
    files_listed: int = 0
    missing: List[Dict[str, Any]] = field(default_factory=list)
    hashes: Dict[str, str] = field(default_factory=dict)
    started_at: str = ""
    finished_at: str = ""
    warnings: List[str] = field(default_factory=list)
    method_note: str = ""

    @property
    def complete(self) -> bool:
        return not self.missing

    def as_dict(self) -> Dict[str, Any]:
        return {
            "device": self.device, "destination": self.destination,
            "files_copied": self.files_copied,
            "bytes_copied": self.bytes_copied,
            "files_listed": self.files_listed,
            "missing_count": len(self.missing),
            "missing": self.missing[:500],
            "complete": self.complete,
            "started_at": self.started_at, "finished_at": self.finished_at,
            "warnings": self.warnings,
            "method_note": self.method_note,
        }


METHOD_NOTE = (
    "Acquired over MTP (Media Transfer Protocol): a file copy served by the "
    "handset's own media provider, not an image of its storage. It reaches "
    "what the provider chooses to expose — shared storage, camera media, "
    "downloads, and app folders under Android/media — and cannot reach "
    "/data/data, where message databases, call logs and their unallocated "
    "space live. Reading a file over MTP may update its access time on the "
    "handset. A file absent from this acquisition was not necessarily absent "
    "from the device."
)


def _powershell(script: str, timeout: int = 900) -> Tuple[str, str]:
    for shell in ("powershell", "pwsh"):
        if not shutil.which(shell):
            continue
        try:
            completed = subprocess.run(
                [shell, "-NoProfile", "-NonInteractive", "-Command", script],
                capture_output=True, text=True, timeout=timeout, check=False)
            return completed.stdout or "", completed.stderr or ""
        except (OSError, subprocess.SubprocessError) as exc:
            return "", str(exc)
    return "", "PowerShell is not available"


def available() -> bool:
    """Is MTP acquisition possible on this platform?"""
    return sys.platform.startswith("win")


def devices() -> List[MTPDevice]:
    """Handsets mounted in the shell namespace (This PC)."""
    if not available():
        return []
    out, _err = _powershell(_ENUMERATE_DEVICES, timeout=60)
    found: List[MTPDevice] = []
    for line in out.splitlines():
        if "|" not in line:
            continue
        name, path = line.split("|", 1)
        name = name.strip()
        if not name or name.lower() in ("desktop", "documents", "downloads",
                                        "music", "pictures", "videos",
                                        "3d objects"):
            continue
        found.append(MTPDevice(name=name, path=path.strip()))
    return found


def list_tree(device_name: str, max_depth: int = 6) -> List[Dict[str, Any]]:
    """Enumerate the device before copying.

    The listing is what makes missing files detectable afterwards. Without it
    there is nothing to compare the copy against, and a partial transfer is
    indistinguishable from a phone that simply held less.
    """
    if not available():
        return []
    script = (_LIST_TREE.replace("__DEVICE__", device_name)
                        .replace("__MAXDEPTH__", str(max_depth)))
    out, _err = _powershell(script, timeout=600)
    entries: List[Dict[str, Any]] = []
    for line in out.splitlines():
        parts = line.split("|", 2)
        if len(parts) != 3:
            continue
        kind, rel, size = parts
        if kind not in ("F", "D"):
            continue
        try:
            size_value = int(size) if size.strip().isdigit() else 0
        except ValueError:
            size_value = 0
        entries.append({"kind": kind, "path": rel, "size": size_value})
    return entries


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1 << 20), b""):
                digest.update(chunk)
    except OSError:
        return ""
    return digest.hexdigest()


def acquire(device_name: str, destination: Path | str,
            progress: Optional[Callable[[str], None]] = None,
            hash_files: bool = True) -> AcquisitionResult:
    """Copy a handset's shared storage, recording hashes and every failure."""
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    result = AcquisitionResult(
        device=device_name, destination=str(destination),
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        method_note=METHOD_NOTE)

    if not available():
        result.warnings.append(
            "MTP acquisition is implemented for Windows only. On Linux or "
            "macOS, mount the handset with your desktop's MTP support and "
            "import the mounted path instead.")
        result.finished_at = time.strftime("%Y-%m-%dT%H:%M:%S%z")
        return result

    def say(message: str) -> None:
        if progress:
            progress(message)

    # 1. Inventory first, so a shortfall afterwards is measurable.
    say(f"Listing {device_name}…")
    listing = list_tree(device_name)
    expected = {e["path"]: e["size"] for e in listing if e["kind"] == "F"}
    result.files_listed = len(expected)
    say(f"{len(expected)} file(s) listed on the device.")

    # 2. Copy.
    say("Copying — MTP is slow; a full handset commonly takes 20-60 minutes.")
    script = (_COPY_TREE.replace("__DEVICE__", device_name)
                        .replace("__DEST__", str(destination)))
    out, err = _powershell(script, timeout=14400)
    if "ERR|" in out:
        result.warnings.append(out.split("ERR|", 1)[1].strip())
    if err.strip():
        result.warnings.append(err.strip()[:400])

    # 3. Reconcile what arrived against what was listed.
    say("Hashing and reconciling…")
    arrived: Dict[str, Path] = {}
    for path in destination.rglob("*"):
        if path.is_file():
            arrived[path.relative_to(destination).as_posix()] = path

    result.files_copied = len(arrived)
    for relative, path in arrived.items():
        try:
            result.bytes_copied += path.stat().st_size
        except OSError:
            pass
        if hash_files:
            digest = _sha256(path)
            if digest:
                result.hashes[relative] = digest

    # A listed file that never arrived is the thing Explorer would not have
    # told anyone about.
    landed = set(arrived)
    for relative, size in expected.items():
        if relative in landed:
            continue
        tail = relative.split("/")[-1]
        if any(candidate.endswith(tail) for candidate in landed):
            continue        # arrived at a different depth; the copy flattens
        result.missing.append({
            "path": relative, "size": size,
            "reason": ("Listed on the handset but not present after the copy. "
                       "MTP transfers fail individually — a file locked by the "
                       "device, a name the host filesystem rejects, or an entry "
                       "the media provider lists but will not serve."),
        })

    result.finished_at = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    if result.missing:
        result.warnings.append(
            f"{len(result.missing)} listed file(s) did not arrive. They are "
            f"itemised in the manifest. Do not treat their absence as evidence "
            f"the handset lacked them.")
    say(f"Done: {result.files_copied} file(s), "
        f"{result.bytes_copied / (1024 ** 3):.2f} GB, "
        f"{len(result.missing)} missing.")
    return result


def write_manifest(result: AcquisitionResult, path: Path | str) -> Path:
    """Record the acquisition beside the evidence.

    Per-file hashes make the copy checkable later, and the missing list is what
    stops an absence being read as a finding.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = result.as_dict()
    payload["hashes"] = result.hashes
    payload["format"] = "argus-mtp-manifest/1"
    path.write_text(json.dumps(payload, indent=1, ensure_ascii=False),
                    encoding="utf-8")
    return path
