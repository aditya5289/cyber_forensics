"""Acquisition engine — the orchestrator for lab manual §5.5 – §5.9.

Runs the whole XRY-side workflow as one auditable transaction:

    Step 8  choose extraction action, gated by the device capability matrix
    Step 9  apply the time span
    Step 10 apply the artifact category filter
    Step 11 record operator and exhibit details
    Step 12 execute, emitting a live module/status/timestamp/message log
    Step 13 seal the container and report completion status

Design rule: **the engine never throws away a partial extraction.**  If a
module fails halfway, whatever was already acquired stays in the container and
the failure is recorded in the log and the manifest.  Discarding partial
evidence because of a late error would be the single worst behaviour a tool
like this could have.
"""

from __future__ import annotations

import shutil
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from ..core.case import Case
from ..core.container import EvidenceContainer, ExtractionMeta
from ..core.errors import AcquisitionError, DeviceNotSupportedError
from ..core.models import Category
from ..devices.detect import DetectedDevice, require_device
from ..devices.manual import DeviceManual
from ..parsers.registry import ParseContext, dispatch, load_all
from ..parsers.timestamps import span_to_range
from . import android_adb, android_backup, ios_backup
from .filesystem import ingest_tree

ALL_CATEGORIES = [c.value for c in Category]


@dataclass
class AcquisitionPlan:
    """Everything Steps 8–11 collect, in one reviewable object."""

    method: str = "logical"                 # logical|filesystem|backup|import
    time_span: str = "all"                  # Step 9
    categories: List[str] = field(default_factory=lambda: list(ALL_CATEGORIES))
    operator: str = ""                      # Step 11
    exhibit_id: str = ""
    lock_state: str = "unlocked"
    device_name: str = ""
    serial: Optional[str] = None
    source_path: Optional[Path] = None      # for import/backup methods
    backup_password: Optional[str] = None
    recover_deleted: bool = True
    carve_confidence: float = 0.45
    owner_identifiers: List[str] = field(default_factory=list)
    owner_name: str = "Device owner"
    notes: str = ""
    keep_raw: bool = True

    def validate(self) -> None:
        if not self.operator:
            raise AcquisitionError(
                "Operator name is required (manual Step 11 — chain of custody)")
        if not self.exhibit_id:
            raise AcquisitionError("Exhibit ID is required (manual Step 11)")
        bad = [c for c in self.categories if c not in ALL_CATEGORIES]
        if bad:
            raise AcquisitionError(
                f"unknown categories {bad}; valid: {ALL_CATEGORIES}")
        span_to_range(self.time_span)       # raises on malformed span


@dataclass
class AcquisitionReport:
    container: str = ""
    method: str = ""
    started_at: str = ""
    finished_at: str = ""
    duration_seconds: float = 0.0
    files_acquired: int = 0
    bytes_acquired: int = 0
    artifacts: int = 0
    deleted_recovered: int = 0
    categories: Dict[str, int] = field(default_factory=dict)
    applications: Dict[str, int] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    integrity_failures: List[str] = field(default_factory=list)
    status: str = "Completed"
    seal: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        from dataclasses import asdict
        return asdict(self)


class AcquisitionEngine:
    """Execute an :class:`AcquisitionPlan` against a case."""

    def __init__(self, case: Case, manual: Optional[DeviceManual] = None,
                 progress: Optional[Callable[[Dict[str, Any]], None]] = None):
        self.case = case
        self.manual = manual or DeviceManual()
        self.progress = progress
        load_all()

    # ------------------------------------------------------------------ Step 8
    def check_support(self, plan: AcquisitionPlan) -> Dict[str, Any]:
        """Gate the extraction against the device manual before touching data."""
        cap = self.manual.assert_supported(
            plan.device_name, plan.lock_state, plan.method)
        return cap.as_dict()

    # ------------------------------------------------------------------- run
    def run(self, plan: AcquisitionPlan,
            device: Optional[DetectedDevice] = None) -> AcquisitionReport:
        plan.validate()
        started = time.time()
        report = AcquisitionReport(
            method=plan.method,
            started_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))

        # The capability matrix gates *device* actions only. An import replays
        # bytes that were already lawfully acquired, so there is no device to
        # damage and nothing to gate — but the device is still recorded so the
        # container states what the evidence came from.
        capability: Dict[str, Any] = {}
        if plan.device_name and plan.method != "import":
            try:
                capability = self.check_support(plan)
            except DeviceNotSupportedError as exc:
                raise AcquisitionError(
                    f"Refusing to start: {exc} "
                    f"(manual §7 precaution 1 — verify device support first)"
                ) from exc

        meta = ExtractionMeta(
            exhibit_id=plan.exhibit_id, operator=plan.operator,
            method=plan.method, time_span=plan.time_span,
            categories=list(plan.categories),
            lock_state=plan.lock_state,
            started_at=report.started_at, notes=plan.notes,
            tool_version=_version(),
        )
        if device:
            meta.device_make = device.make
            meta.device_model = device.marketing_name or device.model
            meta.device_os = f"{device.os_family} {device.os_version}".strip()
            meta.device_serial = device.serial
            meta.imei = device.imei
            meta.iccid = device.iccid
            meta.phone_number = device.phone_number
        elif plan.device_name:
            parts = plan.device_name.split(" ", 1)
            meta.device_make = parts[0]
            meta.device_model = parts[1] if len(parts) > 1 else ""

        container = self.case.new_container(plan.exhibit_id, meta,
                                            label=plan.method)
        report.container = str(container.path)
        self._log(container, "engine", "start",
                  f"Extraction started — method={plan.method}, "
                  f"span={plan.time_span}, "
                  f"categories={len(plan.categories)}/{len(ALL_CATEGORIES)}")
        if capability:
            self._log(container, "device.manual", "ok",
                      f"Capability confirmed: {capability.get('label')} "
                      f"({capability.get('risk')} risk)"
                      + (f" — {capability['note']}" if capability.get("note") else ""))

        staging = Path(tempfile.mkdtemp(prefix="argus-acq-"))
        try:
            raw_root = self._acquire(plan, container, staging, device, report)
            self._decode(plan, container, raw_root, report)
        except AcquisitionError as exc:
            report.status = "Failed"
            report.warnings.append(str(exc))
            self._log(container, "engine", "error", str(exc), level="error")
        except Exception as exc:                              # pragma: no cover
            report.status = "Failed"
            report.warnings.append(f"unexpected error: {exc}")
            self._log(container, "engine", "error", f"unexpected: {exc}",
                      level="error")
        finally:
            stats = container.refresh_statistics()
            report.artifacts = int(stats.get("artifacts", 0))
            report.categories = stats.get("categories", {})
            report.applications = stats.get("applications", {})
            rec = stats.get("recovery", {})
            report.deleted_recovered = sum(
                v for k, v in rec.items() if k != "allocated")
            report.finished_at = datetime.now(timezone.utc).isoformat(
                timespec="seconds")
            report.duration_seconds = round(time.time() - started, 2)
            container.update_extraction(finished_at=report.finished_at)

            if report.status != "Failed":
                report.status = ("Completed" if not report.integrity_failures
                                 else "Completed with integrity warnings")
            self._log(container, "engine", report.status.lower().split()[0],
                      f"Extraction {report.status.lower()} — "
                      f"{report.artifacts} artifacts "
                      f"({report.deleted_recovered} recovered from deleted "
                      f"space) in {report.duration_seconds}s")
            try:
                report.seal = container.seal()
                self._log(container, "engine", "sealed",
                          f"Container sealed: "
                          f"{report.seal['container_seal'][:32]}…")
            except Exception as exc:
                report.warnings.append(f"seal failed: {exc}")
            container.close()
            self.case.audit.record("extraction.complete", {
                "container": Path(report.container).name,
                "status": report.status,
                "artifacts": report.artifacts,
                "deleted_recovered": report.deleted_recovered,
                "duration_seconds": report.duration_seconds,
                "seal": (report.seal or {}).get("container_seal", "")[:32],
            })
            shutil.rmtree(staging, ignore_errors=True)
        return report

    # -------------------------------------------------------------- acquire
    def _acquire(self, plan: AcquisitionPlan, container: EvidenceContainer,
                 staging: Path, device: Optional[DetectedDevice],
                 report: AcquisitionReport) -> Path:
        """Get bytes off the device (or off disk) into a staging tree."""
        raw_root = (container.path / "raw") if plan.keep_raw else staging
        raw_root.mkdir(parents=True, exist_ok=True)
        log = lambda *a, **k: self._log(container, *a, **k)

        if plan.method == "import":
            src = Path(plan.source_path or "")
            if not src.exists():
                raise AcquisitionError(f"import source not found: {src}")

            # Format detection is delegated to the adapter registry, so ARGUS
            # accepts another tool's extraction as readily as its own. Most
            # evidence an examiner receives was not acquired by the tool they
            # are using.
            from . import adapters
            described = adapters.describe(src)
            if not described.get("ok"):
                raise AcquisitionError(
                    f"{described.get('reason')} — supported sources: "
                    + ", ".join(a.label for a in adapters.adapters()))
            log("import", "start",
                f"Identified as {described['label']}: {src}")

            staged = adapters.stage(src, raw_root, plan)
            report.files_acquired += staged.files
            report.bytes_acquired += staged.bytes_staged
            report.warnings.extend(staged.warnings[:80])
            report.notes.extend(staged.notes[:40])

            container.update_extraction(
                source_format=staged.source_format,
                import_adapter=staged.adapter)
            if staged.device:
                container.update_extraction(**_device_fields(staged.device))
            if staged.foreign_decoded:
                # Another tool's decoded output is recorded as provenance, never
                # adopted as an ARGUS finding — the examiner must be able to see
                # which tool decoded what.
                container.manifest.setdefault(
                    "foreign_provenance", staged.foreign_decoded)
                container._write_manifest()
                log("import", "note",
                    f"Recorded {len(staged.foreign_decoded)} decoded model "
                    f"group(s) from the originating tool as foreign "
                    f"provenance (attributed to it, not to ARGUS)")
            for note in staged.notes[:6]:
                log("import", "note", note)
            log("import", "ok",
                f"{staged.source_format}: {staged.files} file(s), "
                f"{_human(staged.bytes_staged)}"
                + (f", platform {staged.platform}" if staged.platform else ""))
            if staged.platform:
                self._staged_platform = staged.platform
            return raw_root

        # ------------------------------------------------ live device methods
        dev = device or require_device(plan.serial)
        log("device", "ok",
            f"Device identified: {dev.name} "
            f"({dev.os_family} {dev.os_version}, serial {dev.serial})")
        if dev.battery is not None and dev.battery < 20:
            log("device", "warning",
                f"Battery at {dev.battery}% — connect a charger before a long "
                f"extraction. Do not disconnect during extraction (manual §7).",
                level="warning")

        if dev.os_family == "Android":
            session = android_adb.AdbSession(dev.serial)
            android_adb.device_report(session, raw_root)
            if plan.method == "logical":
                res = android_adb.logical_query(session, raw_root,
                                                plan.categories, log)
            elif plan.method == "filesystem":
                res = android_adb.pull_filesystem(session, raw_root,
                                                  plan.categories, log=log)
            elif plan.method == "backup":
                ab = android_adb.create_backup(session, staging,
                                               plan.backup_password or "", log)
                if not ab:
                    raise AcquisitionError(
                        "adb backup returned no data (Android 12+ restricts it; "
                        "try the filesystem method)")
                n, warns = android_backup.extract(ab, raw_root,
                                                  plan.backup_password)
                report.files_acquired += n
                report.warnings.extend(warns)
                res = android_adb.PullResult(pulled=[str(ab)],
                                             bytes_total=ab.stat().st_size)
            else:
                raise AcquisitionError(
                    f"method '{plan.method}' is not implemented for Android")
            report.files_acquired += len(res.pulled)
            report.bytes_acquired += res.bytes_total
            report.integrity_failures.extend(res.integrity_failures)
            report.warnings.extend(res.failed)
            return raw_root

        if dev.os_family == "iOS":
            raise AcquisitionError(
                "Live iOS acquisition requires idevicebackup2. Create the "
                "backup with `idevicebackup2 backup --full <dir>` and then "
                "run ARGUS with --method import --source <dir>.")

        raise AcquisitionError(f"unsupported platform: {dev.os_family}")

    def _ios_backup(self, src: Path, raw_root: Path,
                    container: EvidenceContainer, report: AcquisitionReport,
                    plan: AcquisitionPlan) -> None:
        backup = ios_backup.IOSBackup(src)
        info = backup.device_info()
        container.update_extraction(
            device_make="Apple",
            device_model=info.get("product_type", ""),
            device_os=f"iOS {info.get('product_version','')}".strip(),
            device_serial=info.get("serial_number", ""),
            imei=info.get("imei", ""), iccid=info.get("iccid", ""),
            phone_number=info.get("phone_number", ""))
        self._log(container, "ios.backup", "ok",
                  f"Backup identified: {info.get('device_name')} "
                  f"{info.get('product_type')} iOS {info.get('product_version')}")
        if backup.encrypted:
            raise AcquisitionError(
                "iOS backup is encrypted. Supply the backup password, or "
                "produce an unencrypted backup with "
                "`idevicebackup2 encryption off <password>`.")
        written, total, warns = backup.rebuild(
            raw_root, progress=lambda n, b, p: self._log(
                container, "ios.backup", "progress",
                f"{n} files rebuilt ({_human(b)}) — {p}"))
        report.files_acquired += written
        report.bytes_acquired += total
        report.warnings.extend(warns[:50])
        self._log(container, "ios.backup", "ok",
                  f"Logical tree rebuilt: {written} files, {_human(total)}")

    # --------------------------------------------------------------- decode
    def _decode(self, plan: AcquisitionPlan, container: EvidenceContainer,
                raw_root: Path, report: AcquisitionReport) -> None:
        """Step 13's "Decode" action: turn raw bytes into artifacts."""
        lo, hi = span_to_range(plan.time_span)
        # An adapter that read a source's own metadata knows the platform more
        # reliably than a heuristic over directory names.
        platform = getattr(self, "_staged_platform", "") or _guess_platform(
            raw_root)
        self._log(container, "decode", "start",
                  f"Decoding {platform or 'unknown platform'} evidence tree"
                  + (f" (time span {plan.time_span})" if lo else ""))

        ctx = ParseContext(
            evidence_root=raw_root, platform=platform,
            owner_identifiers=plan.owner_identifiers,
            owner_name=plan.owner_name,
            recover_deleted=plan.recover_deleted,
            carve_confidence=plan.carve_confidence,
            store_blob=lambda p, rel: container.store_file(p, rel).sha256,
            log=lambda *a, **k: self._log(container, *a, **k),
            time_lo=lo, time_hi=hi, categories=plan.categories,
        )
        result = ingest_tree(raw_root, ctx, container)
        report.warnings.extend(result.warnings[:200])
        report.notes.extend(result.notes[:200])
        if not report.files_acquired:
            report.files_acquired = result.files_seen
            report.bytes_acquired = result.bytes_seen
        self._log(container, "decode", "ok",
                  f"Decoded {len(result.artifacts)} artifacts from "
                  f"{result.files_parsed} of {result.files_seen} files")

    # ------------------------------------------------------------------- log
    def _log(self, container: EvidenceContainer, module: str, status: str,
             message: str, level: str = "info", **extra: Any) -> None:
        entry = container.log(module, status, message, level=level, **extra)
        if self.progress:
            try:
                self.progress(entry)
            except Exception:                                 # pragma: no cover
                pass


def _device_fields(device: Dict[str, Any]) -> Dict[str, str]:
    """Map an adapter's device dictionary onto container metadata fields.

    Source tools use wildly different key names for the same facts, so this maps
    a generous set of aliases rather than requiring one spelling.
    """
    aliases = {
        "device_make": ("make", "manufacturer", "vendor", "Device Make",
                        "Manufacturer"),
        "device_model": ("model", "product_type", "Device Model", "Model",
                         "device_name", "Device Name", "device"),
        "device_os": ("os", "os_version", "product_version", "OS Version",
                      "Operating System", "software_version"),
        "device_serial": ("serial", "serial_number", "Serial Number", "udid",
                          "unique_identifier"),
        "imei": ("imei", "IMEI", "imei1"),
        "iccid": ("iccid", "ICCID"),
        "phone_number": ("phone_number", "msisdn", "Phone Number"),
    }
    lowered = {str(k).strip().lower(): str(v) for k, v in device.items()}
    out: Dict[str, str] = {}
    for field_name, keys in aliases.items():
        for key in keys:
            value = lowered.get(key.strip().lower())
            if value:
                out[field_name] = value[:200]
                break
    return out


def _guess_platform(root: Path) -> str:
    markers_android = ["data/data", "sdcard", "build.prop", "packages.list",
                       "apps/", "mmssms.db", "contacts2.db"]
    markers_ios = ["HomeDomain", "CameraRollDomain", "Manifest.db", "sms.db",
                   "AddressBook.sqlitedb", "Library/SMS"]
    blob = " ".join(p.as_posix() for p in list(root.rglob("*"))[:4000]).lower()
    a = sum(1 for m in markers_android if m.lower() in blob)
    i = sum(1 for m in markers_ios if m.lower() in blob)
    if a > i:
        return "android"
    if i > a:
        return "ios"
    return ""


def _copy_tree(src: Path, dest: Path) -> tuple[int, int]:
    n = total = 0
    for p in src.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(src)
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(p, target)
            n += 1
            total += target.stat().st_size
        except OSError:
            continue
    return n, total


def _human(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} PB"


def _version() -> str:
    from .. import __version__
    return __version__
