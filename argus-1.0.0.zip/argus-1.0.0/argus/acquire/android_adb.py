"""Live Android acquisition over ADB.

Two extraction actions are implemented, matching the manual's Step 8:

* **Logical (Full read)** — queries the device's own content providers
  (``content query --uri content://...``).  This is what the OS is willing to
  hand over to a normal app, so it needs no root, but it returns *allocated
  records only*: deleted messages are already gone at this layer.

* **File system** — pulls the actual database files (and their ``-wal`` /
  ``-journal`` sidecars) so the deleted-record carver has something to work
  with.  Without root this reaches shared storage and whatever ``run-as``
  allows on debuggable packages; with root it reaches ``/data/data``.

Every pulled file is hashed on the device (``sha256sum``) *and* on the
workstation, and the two are compared.  A mismatch means the transfer was
corrupted and is reported as an integrity failure rather than silently
accepted.
"""

from __future__ import annotations

import re
import shlex
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Tuple

from ..core.errors import AcquisitionError
from ..core.hashing import hash_file

# Content-provider URIs used by the logical action
PROVIDERS: Dict[str, Tuple[str, str]] = {
    "calls": ("content://call_log/calls", "Calls"),
    "contacts": ("content://com.android.contacts/data/phones", "Contacts"),
    "sms": ("content://sms", "Messages"),
    "mms": ("content://mms", "Messages"),
    "threads": ("content://mms-sms/conversations", "Messages"),
    "images": ("content://media/external/images/media", "Files & Media"),
    "video": ("content://media/external/video/media", "Files & Media"),
    "audio": ("content://media/external/audio/media", "Files & Media"),
    "downloads": ("content://downloads/my_downloads", "Files & Media"),
    "calendar": ("content://com.android.calendar/events", "Calendar"),
}

# Paths pulled by the file-system action, in priority order
FS_TARGETS: List[Tuple[str, str]] = [
    ("/data/data/com.android.providers.telephony/databases/mmssms.db", "Messages"),
    ("/data/data/com.android.providers.contacts/databases/contacts2.db", "Contacts"),
    ("/data/data/com.android.providers.contacts/databases/calllog.db", "Calls"),
    ("/data/data/com.whatsapp/databases/msgstore.db", "Messages"),
    ("/data/data/com.whatsapp/databases/wa.db", "Contacts"),
    ("/data/data/com.android.chrome/app_chrome/Default/History", "Web"),
    ("/data/system/users/0/accounts.db", "Security"),
    ("/data/misc/wifi/WifiConfigStore.xml", "Networks"),
    ("/data/system/packages.list", "Applications"),
    ("/sdcard/DCIM", "Files & Media"),
    ("/sdcard/Pictures", "Files & Media"),
    ("/sdcard/Download", "Files & Media"),
    ("/sdcard/WhatsApp/Media", "Files & Media"),
    ("/sdcard/Movies", "Files & Media"),
]

SIDECARS = ("-wal", "-shm", "-journal")


@dataclass
class PullResult:
    pulled: List[str] = field(default_factory=list)
    skipped: List[str] = field(default_factory=list)
    failed: List[str] = field(default_factory=list)
    bytes_total: int = 0
    integrity_failures: List[str] = field(default_factory=list)


class AdbSession:
    """A thin, defensive wrapper around the ``adb`` binary."""

    def __init__(self, serial: str, timeout: int = 300):
        self.serial = serial
        self.timeout = timeout
        self._root: Optional[bool] = None

    def _cmd(self, *args: str) -> List[str]:
        return ["adb", "-s", self.serial, *args]

    def run(self, *args: str, timeout: Optional[int] = None,
            check: bool = False) -> subprocess.CompletedProcess:
        try:
            proc = subprocess.run(self._cmd(*args), capture_output=True,
                                  text=True, timeout=timeout or self.timeout)
        except FileNotFoundError as exc:
            raise AcquisitionError("adb is not installed or not on PATH") from exc
        except subprocess.TimeoutExpired as exc:
            raise AcquisitionError(
                f"adb command timed out after {timeout or self.timeout}s: "
                f"{' '.join(args)[:120]}") from exc
        if check and proc.returncode != 0:
            raise AcquisitionError(
                f"adb {' '.join(args)[:80]} failed: {proc.stderr.strip()[:200]}")
        return proc

    def shell(self, command: str, timeout: Optional[int] = None) -> str:
        return self.run("shell", command, timeout=timeout).stdout

    @property
    def has_root(self) -> bool:
        if self._root is None:
            out = self.shell("id").strip()
            self._root = "uid=0" in out or bool(self.shell("which su").strip())
        return self._root

    def exists(self, remote: str) -> bool:
        probe = f'ls -d {shlex.quote(remote)} 2>/dev/null'
        if self.has_root:
            probe = f'su -c {shlex.quote(probe)}'
        return bool(self.shell(probe).strip())

    def remote_sha256(self, remote: str) -> str:
        cmd = f"sha256sum {shlex.quote(remote)} 2>/dev/null"
        if self.has_root:
            cmd = f"su -c {shlex.quote(cmd)}"
        out = self.shell(cmd).strip()
        m = re.match(r"([0-9a-f]{64})\s", out)
        return m.group(1) if m else ""

    # ------------------------------------------------------------------ pull
    def pull(self, remote: str, local: Path,
             verify: bool = True) -> Tuple[bool, str]:
        """Pull one path. Returns ``(ok, message)``."""
        local.parent.mkdir(parents=True, exist_ok=True)
        proc = self.run("pull", "-a", remote, str(local))
        if proc.returncode != 0:
            if self.has_root:
                staged = f"/data/local/tmp/argus_{abs(hash(remote)) % 10**8}"
                self.shell(f"su -c 'cp -r {shlex.quote(remote)} {staged} && "
                           f"chmod -R 644 {staged}'")
                proc = self.run("pull", "-a", staged, str(local))
                self.shell(f"su -c 'rm -rf {staged}'")
                if proc.returncode != 0:
                    return False, proc.stderr.strip()[:200]
            else:
                return False, proc.stderr.strip()[:200] or "permission denied"

        if verify and local.is_file():
            remote_hash = self.remote_sha256(remote)
            if remote_hash:
                local_hash = hash_file(local).sha256
                if local_hash != remote_hash:
                    return False, (f"integrity mismatch: device reported "
                                   f"{remote_hash[:16]}…, received "
                                   f"{local_hash[:16]}…")
        return True, "ok"


def pull_filesystem(session: AdbSession, dest: Path,
                    categories: Optional[List[str]] = None,
                    extra_paths: Optional[List[str]] = None,
                    log: Optional[Callable[..., None]] = None) -> PullResult:
    """File-system action: pull databases and media, with WAL sidecars."""
    result = PullResult()
    targets = [(p, c) for p, c in FS_TARGETS
               if not categories or c in categories]
    for p in (extra_paths or []):
        targets.append((p, "Other"))

    if not session.has_root:
        if log:
            log("adb.filesystem", "warning",
                "Device is not rooted — /data/data is unreadable. Only shared "
                "storage will be acquired. Deleted-record recovery will be "
                "limited to what is present in shared storage.",
                level="warning")

    for remote, category in targets:
        if not session.exists(remote):
            result.skipped.append(remote)
            if log:
                log("adb.filesystem", "skipped", f"{remote} not present")
            continue
        local = dest / remote.lstrip("/")
        ok, msg = session.pull(remote, local)
        if ok:
            result.pulled.append(remote)
            size = _tree_size(local)
            result.bytes_total += size
            if log:
                log("adb.filesystem", "ok", f"pulled {remote}",
                    category=category, bytes=size)
            # WAL/journal sidecars are where deleted rows survive
            if local.is_file():
                for suffix in SIDECARS:
                    sc = remote + suffix
                    if session.exists(sc):
                        sok, _ = session.pull(sc, Path(str(local) + suffix))
                        if sok:
                            result.pulled.append(sc)
                            if log:
                                log("adb.filesystem", "ok",
                                    f"pulled sidecar {Path(sc).name}")
        else:
            result.failed.append(f"{remote}: {msg}")
            if "integrity mismatch" in msg:
                result.integrity_failures.append(f"{remote}: {msg}")
            if log:
                log("adb.filesystem", "error", f"{remote}: {msg}", level="error")
    return result


def logical_query(session: AdbSession, dest: Path,
                  categories: Optional[List[str]] = None,
                  log: Optional[Callable[..., None]] = None) -> PullResult:
    """Logical action: query content providers and save the raw dumps."""
    result = PullResult()
    dest.mkdir(parents=True, exist_ok=True)
    for key, (uri, category) in PROVIDERS.items():
        if categories and category not in categories:
            continue
        out = session.shell(f"content query --uri {uri}", timeout=180)
        if not out.strip() or "Error" in out[:200]:
            result.skipped.append(uri)
            if log:
                log("adb.logical", "skipped",
                    f"{uri}: {out.strip()[:120] or 'no rows returned'}")
            continue
        target = dest / "content" / f"{key}.txt"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(out, encoding="utf-8")
        result.pulled.append(uri)
        result.bytes_total += target.stat().st_size
        rows = out.count("Row:")
        if log:
            log("adb.logical", "ok", f"{uri}: {rows} rows", category=category)
    return result


def device_report(session: AdbSession, dest: Path) -> Path:
    """Capture device state for the record (Step 11 supporting detail)."""
    dest.mkdir(parents=True, exist_ok=True)
    target = dest / "device_info.txt"
    blocks = {
        "getprop": session.shell("getprop"),
        "battery": session.shell("dumpsys battery"),
        "packages": session.shell("pm list packages -f -u"),
        "users": session.shell("pm list users"),
        "accounts": session.shell("dumpsys account | head -100"),
        "df": session.shell("df -h"),
        "date": session.shell("date"),
        "uptime": session.shell("uptime"),
        "sim": session.shell("dumpsys telephony.registry | head -60"),
    }
    with target.open("w", encoding="utf-8") as fh:
        for name, body in blocks.items():
            fh.write(f"\n===== {name} =====\n{body}\n")
    return target


def create_backup(session: AdbSession, dest: Path,
                  password: str = "", log=None) -> Optional[Path]:
    """Backup action: trigger ``adb backup``. Requires on-device confirmation."""
    dest.mkdir(parents=True, exist_ok=True)
    target = dest / "backup.ab"
    if log:
        log("adb.backup", "waiting",
            "Confirm the backup prompt on the device screen. This will time "
            "out after 10 minutes.", level="warning")
    proc = session.run("backup", "-apk", "-shared", "-all", "-f", str(target),
                       timeout=600)
    if proc.returncode != 0 or not target.exists() or target.stat().st_size < 64:
        if log:
            log("adb.backup", "error",
                "backup produced no data — Android 12+ and apps with "
                "allowBackup=false will refuse", level="error")
        return None
    return target


def _tree_size(path: Path) -> int:
    if path.is_file():
        try:
            return path.stat().st_size
        except OSError:
            return 0
    total = 0
    for p in path.rglob("*"):
        if p.is_file():
            try:
                total += p.stat().st_size
            except OSError:
                pass
    return total
