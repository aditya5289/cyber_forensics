"""Artifact database — the analytical store inside an evidence container.

A single SQLite file holds every normalised artifact plus a full-text index.
It is written once during acquisition/parsing and thereafter opened read-only
by the analysis layer.

Why SQLite and not a document store: an evidence container has to be a *single
portable file set* that opens on an air-gapped workstation ten years from now
with no server process.  SQLite is the only format that credibly meets that
bar, and it gives us FTS5 for free.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence

from .models import Artifact, Category, Direction, Participant, Recovery

SCHEMA_VERSION = 3

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS meta (
    key    TEXT PRIMARY KEY,
    value  TEXT
);

CREATE TABLE IF NOT EXISTS artifact (
    artifact_id   TEXT PRIMARY KEY,
    category      TEXT NOT NULL,
    subtype       TEXT NOT NULL DEFAULT '',
    timestamp     INTEGER,
    timestamp_end INTEGER,
    body          TEXT NOT NULL DEFAULT '',
    direction     TEXT NOT NULL DEFAULT 'unknown',
    app           TEXT NOT NULL DEFAULT '',
    source_path   TEXT NOT NULL DEFAULT '',
    source_table  TEXT NOT NULL DEFAULT '',
    source_row    INTEGER,
    recovery      TEXT NOT NULL DEFAULT 'allocated',
    blob_sha256   TEXT NOT NULL DEFAULT '',
    latitude      REAL,
    longitude     REAL,
    confidence    REAL NOT NULL DEFAULT 1.0,
    attributes    TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS ix_artifact_cat  ON artifact(category);
CREATE INDEX IF NOT EXISTS ix_artifact_ts   ON artifact(timestamp);
CREATE INDEX IF NOT EXISTS ix_artifact_app  ON artifact(app);
CREATE INDEX IF NOT EXISTS ix_artifact_rec  ON artifact(recovery);
CREATE INDEX IF NOT EXISTS ix_artifact_blob ON artifact(blob_sha256);

CREATE TABLE IF NOT EXISTS participant (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    artifact_id  TEXT NOT NULL REFERENCES artifact(artifact_id) ON DELETE CASCADE,
    identifier   TEXT NOT NULL DEFAULT '',
    normalised   TEXT NOT NULL DEFAULT '',
    display_name TEXT NOT NULL DEFAULT '',
    role         TEXT NOT NULL DEFAULT 'party',
    is_owner     INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_part_artifact ON participant(artifact_id);
CREATE INDEX IF NOT EXISTS ix_part_norm     ON participant(normalised);

CREATE TABLE IF NOT EXISTS tag (
    artifact_id TEXT NOT NULL REFERENCES artifact(artifact_id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    colour      TEXT NOT NULL DEFAULT '#e2b33c',
    note        TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL DEFAULT '',
    actor       TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (artifact_id, name)
);
CREATE INDEX IF NOT EXISTS ix_tag_name ON tag(name);

CREATE TABLE IF NOT EXISTS source (
    path        TEXT PRIMARY KEY,
    sha256      TEXT NOT NULL DEFAULT '',
    size        INTEGER NOT NULL DEFAULT 0,
    parser      TEXT NOT NULL DEFAULT '',
    count       INTEGER NOT NULL DEFAULT 0,
    notes       TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS blob (
    sha256      TEXT PRIMARY KEY,
    size        INTEGER NOT NULL DEFAULT 0,
    md5         TEXT NOT NULL DEFAULT '',
    sha1        TEXT NOT NULL DEFAULT '',
    mime        TEXT NOT NULL DEFAULT '',
    orig_path   TEXT NOT NULL DEFAULT '',
    stored_at   TEXT NOT NULL DEFAULT ''
);

CREATE VIRTUAL TABLE IF NOT EXISTS artifact_fts USING fts5(
    artifact_id UNINDEXED,
    body,
    parties,
    app,
    subtype,
    tokenize = 'unicode61 remove_diacritics 2'
);
"""


class ArtifactDB:
    """Read/write access to the artifact store."""

    def __init__(self, path: Path | str, read_only: bool = False):
        self.path = Path(path)
        self.read_only = read_only
        if read_only:
            uri = f"file:{self.path.as_posix()}?mode=ro"
            self.conn = sqlite3.connect(uri, uri=True, check_same_thread=False)
        else:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.conn = sqlite3.connect(self.path, check_same_thread=False)
            self.conn.executescript(SCHEMA)
            self.set_meta("schema_version", str(SCHEMA_VERSION))
        self.conn.row_factory = sqlite3.Row

    # ------------------------------------------------------------------- meta
    def set_meta(self, key: str, value: Any) -> None:
        self.conn.execute(
            "INSERT INTO meta(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value) if not isinstance(value, str) else value))
        self.conn.commit()

    def get_meta(self, key: str, default: Any = None) -> Any:
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    # -------------------------------------------------------------- artifacts
    def add(self, art: Artifact) -> None:
        self.add_many([art])

    def add_many(self, artifacts: Iterable[Artifact]) -> int:
        rows, prows, frows = [], [], []
        n = 0
        for a in artifacts:
            n += 1
            rows.append((
                a.artifact_id, a.category.value, a.subtype, a.timestamp,
                a.timestamp_end, a.body, a.direction.value, a.app, a.source_path,
                a.source_table, a.source_row, a.recovery.value, a.blob_sha256,
                a.latitude, a.longitude, a.confidence,
                json.dumps(a.attributes, ensure_ascii=False, default=str),
            ))
            party_labels = []
            for p in a.participants:
                prows.append((a.artifact_id, p.identifier, p.normalised(),
                              p.display_name, p.role, 1 if p.is_owner else 0))
                party_labels.append(f"{p.display_name} {p.identifier}".strip())
            frows.append((a.artifact_id, a.body, " ".join(party_labels),
                          a.app, a.subtype))
        with self.conn:
            self.conn.executemany(
                "INSERT OR REPLACE INTO artifact VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                rows)
            self.conn.executemany(
                "INSERT INTO participant(artifact_id,identifier,normalised,"
                "display_name,role,is_owner) VALUES (?,?,?,?,?,?)", prows)
            self.conn.executemany(
                "INSERT INTO artifact_fts(artifact_id,body,parties,app,subtype) "
                "VALUES (?,?,?,?,?)", frows)
        return n

    def get(self, artifact_id: str) -> Optional[Artifact]:
        row = self.conn.execute(
            "SELECT * FROM artifact WHERE artifact_id=?", (artifact_id,)).fetchone()
        return self._hydrate(row) if row else None

    def iter_artifacts(self, where: str = "", params: Sequence[Any] = (),
                       order: str = "timestamp IS NULL, timestamp ASC",
                       limit: Optional[int] = None,
                       offset: int = 0) -> Iterator[Artifact]:
        sql = "SELECT * FROM artifact"
        if where:
            sql += f" WHERE {where}"
        if order:
            sql += f" ORDER BY {order}"
        if limit is not None:
            sql += f" LIMIT {int(limit)} OFFSET {int(offset)}"
        for row in self.conn.execute(sql, tuple(params)):
            yield self._hydrate(row)

    def count(self, where: str = "", params: Sequence[Any] = ()) -> int:
        sql = "SELECT COUNT(*) AS c FROM artifact"
        if where:
            sql += f" WHERE {where}"
        return int(self.conn.execute(sql, tuple(params)).fetchone()["c"])

    def _hydrate(self, row: sqlite3.Row) -> Artifact:
        parts = [
            Participant(identifier=p["identifier"], display_name=p["display_name"],
                        role=p["role"], is_owner=bool(p["is_owner"]))
            for p in self.conn.execute(
                "SELECT * FROM participant WHERE artifact_id=? ORDER BY id",
                (row["artifact_id"],))
        ]
        tags = [t["name"] for t in self.conn.execute(
            "SELECT name FROM tag WHERE artifact_id=? ORDER BY name",
            (row["artifact_id"],))]
        try:
            attrs = json.loads(row["attributes"] or "{}")
        except json.JSONDecodeError:
            attrs = {}
        return Artifact(
            artifact_id=row["artifact_id"],
            category=Category.coerce(row["category"]),
            subtype=row["subtype"] or "",
            timestamp=row["timestamp"],
            timestamp_end=row["timestamp_end"],
            body=row["body"] or "",
            participants=parts,
            direction=Direction(row["direction"]) if row["direction"] in
                      {d.value for d in Direction} else Direction.UNKNOWN,
            app=row["app"] or "",
            source_path=row["source_path"] or "",
            source_table=row["source_table"] or "",
            source_row=row["source_row"],
            recovery=Recovery(row["recovery"]) if row["recovery"] in
                     {r.value for r in Recovery} else Recovery.ALLOCATED,
            blob_sha256=row["blob_sha256"] or "",
            latitude=row["latitude"], longitude=row["longitude"],
            confidence=row["confidence"] if row["confidence"] is not None else 1.0,
            attributes=attrs, tags=tags,
        )

    # ------------------------------------------------------------------- FTS
    def search_ids(self, query: str, limit: int = 5000) -> List[str]:
        sql = ("SELECT artifact_id FROM artifact_fts WHERE artifact_fts MATCH ? "
               "ORDER BY rank LIMIT ?")
        try:
            return [r["artifact_id"] for r in self.conn.execute(sql, (query, limit))]
        except sqlite3.OperationalError as exc:
            raise ValueError(f"invalid full-text query: {exc}") from exc

    # ------------------------------------------------------------------- tags
    def tag(self, artifact_id: str, name: str, colour: str = "#e2b33c",
            note: str = "", actor: str = "") -> None:
        from datetime import datetime, timezone
        with self.conn:
            self.conn.execute(
                "INSERT OR REPLACE INTO tag VALUES (?,?,?,?,?,?)",
                (artifact_id, name, colour, note,
                 datetime.now(timezone.utc).isoformat(timespec="seconds"), actor))

    def untag(self, artifact_id: str, name: str) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM tag WHERE artifact_id=? AND name=?",
                              (artifact_id, name))

    def tag_names(self) -> List[Dict[str, Any]]:
        return [dict(r) for r in self.conn.execute(
            "SELECT name, colour, COUNT(*) AS count FROM tag "
            "GROUP BY name, colour ORDER BY count DESC")]

    # ---------------------------------------------------------------- sources
    def register_source(self, path: str, sha256: str, size: int, parser: str,
                        count: int, notes: str = "") -> None:
        with self.conn:
            self.conn.execute(
                "INSERT INTO source(path,sha256,size,parser,count,notes) VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(path) DO UPDATE SET sha256=excluded.sha256,"
                "size=excluded.size,parser=excluded.parser,count=excluded.count,"
                "notes=excluded.notes",
                (path, sha256, size, parser, count, notes))

    def sources(self) -> List[Dict[str, Any]]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM source ORDER BY count DESC, path")]

    def register_blob(self, sha256: str, size: int, md5: str = "", sha1: str = "",
                      mime: str = "", orig_path: str = "") -> None:
        from datetime import datetime, timezone
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO blob VALUES (?,?,?,?,?,?,?)",
                (sha256, size, md5, sha1, mime, orig_path,
                 datetime.now(timezone.utc).isoformat(timespec="seconds")))

    def blob_info(self, sha256: str) -> Optional[Dict[str, Any]]:
        row = self.conn.execute("SELECT * FROM blob WHERE sha256=?", (sha256,)).fetchone()
        return dict(row) if row else None

    def all_blob_hashes(self) -> List[str]:
        return [r["sha256"] for r in self.conn.execute("SELECT sha256 FROM blob")]

    # ------------------------------------------------------------- aggregates
    def category_counts(self) -> Dict[str, int]:
        return {r["category"]: r["c"] for r in self.conn.execute(
            "SELECT category, COUNT(*) AS c FROM artifact GROUP BY category "
            "ORDER BY c DESC")}

    def app_counts(self) -> Dict[str, int]:
        return {r["app"]: r["c"] for r in self.conn.execute(
            "SELECT app, COUNT(*) AS c FROM artifact WHERE app<>'' "
            "GROUP BY app ORDER BY c DESC")}

    def recovery_counts(self) -> Dict[str, int]:
        return {r["recovery"]: r["c"] for r in self.conn.execute(
            "SELECT recovery, COUNT(*) AS c FROM artifact GROUP BY recovery")}

    def time_bounds(self) -> tuple[Optional[int], Optional[int]]:
        row = self.conn.execute(
            "SELECT MIN(timestamp) AS lo, MAX(timestamp) AS hi FROM artifact "
            "WHERE timestamp IS NOT NULL").fetchone()
        return (row["lo"], row["hi"]) if row else (None, None)

    # ------------------------------------------------------------------ close
    def optimise(self) -> None:
        """Compact the store and drop out of WAL mode.

        Switching to ``journal_mode=DELETE`` matters for sealing: a WAL-mode
        database mutates its main file when the last connection closes, which
        would invalidate any digest taken beforehand.
        """
        if self.read_only:
            return
        with self.conn:
            self.conn.execute(
                "INSERT INTO artifact_fts(artifact_fts) VALUES('optimize')")
        self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        self.conn.execute("PRAGMA journal_mode=DELETE")
        self.conn.execute("VACUUM")
        self.conn.commit()

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:                                     # pragma: no cover
            pass

    def __enter__(self) -> "ArtifactDB":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
