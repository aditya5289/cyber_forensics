@echo off
rem ===================================================================
rem  ARGUS Forensics - Windows launcher
rem  Double-click this file to start the application.
rem ===================================================================
setlocal
title ARGUS Forensics
cd /d "%~dp0"

rem Find a usable Python. The py launcher is preferred because it picks the
rem newest installed version; fall back to whatever 'python' resolves to.
set "PYEXE="
where py >nul 2>&1 && set "PYEXE=py -3"
if not defined PYEXE (
    where python >nul 2>&1 && set "PYEXE=python"
)
if not defined PYEXE (
    echo.
    echo   ----------------------------------------------------------------
    echo    ARGUS cannot start: Python was not found on this computer.
    echo   ----------------------------------------------------------------
    echo.
    echo    Install Python 3.10 or newer from:
    echo        https://www.python.org/downloads/
    echo.
    echo    IMPORTANT: during installation, tick the box
    echo        "Add Python to PATH"
    echo    then run this launcher again.
    echo.
    pause
    exit /b 1
)

echo.
echo   Starting ARGUS Forensics...
echo   A browser window will open shortly.
echo   Keep this window open while you work - closing it stops ARGUS.
echo.

%PYEXE% "%~dp0argus_app.py" %*
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
    echo.
    echo   ARGUS exited with code %RC%.
    pause
)
endlocal
