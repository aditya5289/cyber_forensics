# ARGUS Forensics

A mobile device forensic acquisition and analysis toolkit implementing the full
workflow in the MSAB XRY / XAMN lab manual — device support verification, case
and exhibit management, extraction, artifact decoding, link analysis and court-
ready reporting.

Two halves, mirroring the two tools in the manual:

| | Manual equivalent | What it does |
|---|---|---|
| `argus.acquire` | **XRY** | Device manual lookup, case creation, logical / file-system / backup extraction, live extraction log |
| `argus.analyze` | **XAMN** | Timeline, connection graph, query language, gallery, tagging, reporting |

Between them sits the **ARGUS Forensic Container** (`.afc`) — a sealed,
content-addressed, hash-chained evidence unit that is the equivalent of the
`.xry` file.

---

## Why this exists in this shape

Three design decisions drive everything else.

**1. Deleted records are the point.** A logical extraction that returns only
live rows tells you what the user did *not* bother to hide. ARGUS ships a real
SQLite record carver that recovers rows from freeblocks, page slack, freelist
pages, write-ahead logs and rollback journals — including rows whose cell
headers were overwritten when SQLite freed them. On the bundled test corpus it
recovers every planted deleted message.

**2. Nothing is trusted, including ARGUS.** Every blob is hashed on ingest and
re-hashed on verification. The container is sealed with a Merkle root over all
blobs plus a digest of the artifact database. The chain-of-custody log is
hash-chained so that editing or removing any entry invalidates every entry
after it. Tampering with a photo, the database or the custody log are all
detected — there are tests for each.

**3. Silence is a finding.** "0 messages" and "0 messages because the database
is SQLCipher-encrypted" are different results, and ARGUS never conflates them.
Parsers report what they could not read. Timestamps that cannot be interpreted
plausibly are returned as `None` rather than as 1970. Reports lead with the
integrity statement, and if verification failed, they say so on page one in red
before any finding is presented.

---

## Run it — one click

| Platform | Double-click |
|---|---|
| Windows | **`ARGUS.bat`** |
| macOS | **`ARGUS.command`** |
| Linux | **`ARGUS.sh`** |

That is the whole install story. The launcher finds Python, checks the
environment, starts a local service and opens the Workbench in your browser.
If Python is missing it says so in plain language and tells you where to get
it, rather than flashing a console window and vanishing.

The Workbench walks the entire lab manual in six steps down the left rail:

```
1 Case      create or open a case                     §5.2  Steps 3–5
2 Exhibit   register the seized device                      chain of custody
3 Support   detect handsets, check the capability matrix  §5.1  Steps 1–2
4 Extract   choose method, span, categories, run live   §5.5–5.9  Steps 8–13
5 Analyse   timeline, graph, gallery, deleted records    §6    Steps 14–20
6 Findings  ranked leads, entities, correlation              beyond the manual
7 Report    export HTML / PDF / XLSX / DOCX / XML        §6.8  Step 21
```

Each step unlocks the next, and completed steps are ticked, so an examiner
cannot skip registering the exhibit and end up with an extraction that has no
custody record. Connected devices are detected automatically; when nothing is
plugged in, the app says why and offers **Import** instead.

Everything is kept in `~/ARGUS` by default — pass `--workspace D:\Cases` to
put it elsewhere.

### Optional extras

The app runs with nothing installed. Missing optional packages disable
specific features and the app tells you exactly which, in the sidebar and on
the Report step:

```bash
pip install pillow openpyxl python-docx reportlab pycryptodome
```

They enable EXIF/GPS extraction and the Excel, Word and PDF report formats.
HTML, XML, JSON and CSV always work.

---

## Install (for command-line use)

```bash
cd argus-forensics
pip install -e .            # core toolkit, zero dependencies
pip install -e ".[all]"     # + EXIF, XLSX/DOCX/PDF export, encrypted backups
```

Python 3.10+. The core — acquisition, carving, analysis, the web UI, and
HTML/XML/JSON/CSV reports — has **no third-party dependencies**, because a
forensic workstation is frequently air-gapped.

Optional extras enable: `pillow` (EXIF/GPS), `openpyxl` / `python-docx` /
`reportlab` (XLSX / DOCX / PDF reports), `pycryptodome` (encrypted `.ab`
backups).

For live device acquisition you also need the vendor toolchains on `PATH`:
`adb` (Android) and `libimobiledevice` (iOS). `argus devices` tells you which
are missing rather than silently reporting "no device found".

---

## Quick start (command line)

Everything the Workbench does is also available from the CLI. Generate a
synthetic device tree, then run the whole manual end to end:

```bash
# Synthetic evidence: real SQLite schemas, real JPEGs with real EXIF GPS,
# and records that are genuinely deleted so the carver has real work to do.
python samples/make_device.py --out ./evidence

# §5.1 Steps 1–2 — verify device support BEFORE touching the device
argus manual search "iPhone 12"
argus manual show "Samsung Galaxy S21 5G"

# §5.2 Steps 3–5 — create the case
argus case new --dir ./cases --id CASE-LAB-001 \
    --investigator "A. Sharma" --organisation "State Cyber Cell"

# Register the seized item (chain of custody)
argus exhibit add ./cases/CASE-LAB-001 EXH-001 \
    --make Samsung --model "Galaxy S21 5G" --imei 356938035643809 \
    --seized-by "Insp. R. Kulkarni" --isolation "Faraday pouch"

# §5.5–5.9 Steps 8–13 — extract, decode, seal
argus acquire ./cases/CASE-LAB-001 --exhibit EXH-001 \
    --operator "A. Sharma" --method import --source ./evidence/android \
    --device "Samsung Galaxy S21 5G" --span all

# §7 precaution 5 — verify integrity before analysis
argus verify ./cases/CASE-LAB-001/exhibits/EXH-001/*.afc

# §6 Steps 14–20 — open the analysis UI
argus analyze ./cases/CASE-LAB-001/exhibits/EXH-001/*.afc

# §6.8 Step 21 — generate the report
argus report ./cases/CASE-LAB-001/exhibits/EXH-001/*.afc \
    --out ./reports --formats html,pdf,xlsx,docx,xml \
    --examiner "A. Sharma" --reference "FIR 114/2026"
```

---

## The analysis UI

`argus analyze` starts a local server (127.0.0.1 only) and opens a XAMN-style
interface with the views the manual asks for:

- **Overview** — case info, device identity, category and application counts
- **Messages / Calls / Contacts** — list and column views, sortable
- **Pictures & Videos** — gallery with GPS and extension-mismatch flags
- **Connection** — force-directed communication graph with identity resolution,
  edge weights, reciprocity and broker detection
- **Timeline** — activity by hour, weekday and day; bursts, silences, and
  timestamp anomalies
- **Places** — map of every geolocated artifact
- **Deleted** — everything recovered from unallocated space, ranked by confidence
- **Extraction log** — the live module/status/timestamp log from the acquisition

Deleted records are marked in purple everywhere they appear, in the UI and in
every report format.

---

## AQL — the query language

The filter panel is exposed directly, because the useful queries are the ones
no checkbox anticipated:

```
category:Messages AND deleted:true
app:WhatsApp AND after:2026-01-01 AND before:2026-03-31
"meet me" OR "the package"
party:9876543210 AND (category:Calls OR category:Messages)
has:gps AND category:"Files & Media"
category:Calls AND direction:missed
NOT app:Instagram AND tag:relevant
confidence:>0.8 AND deleted:true
```

Fields: `category` `app` `type` `direction` `recovery` `source` `table` `body`
`party` `tag` `deleted` `after` `before` `span` `has` `confidence` `id`.
Operators: `AND` `OR` `NOT` `-`, parentheses, quoted phrases. Implicit `AND`.

Everything compiles to a **parameterised** SQL `WHERE` clause — a query
containing an apostrophe is a search term, never syntax.

---

## Deleted-record recovery

`argus carve` runs the recovery engine standalone against any SQLite file:

```bash
argus carve ./evidence/android/data/data/com.whatsapp/databases/msgstore.db
argus carve mmssms.db --table sms --confidence 0.6 --json
```

The carver makes three passes over every unallocated region, each more
permissive than the last and each carrying a correspondingly higher confidence
bar and a lower reported confidence:

1. **Complete cells** — payload length and rowid intact; all three lengths must
   agree exactly. Confidence up to 1.0.
2. **Prefix destroyed** — the cell header is gone but the record header
   survives. Validated on column count and type agreement. Confidence ×0.85.
3. **Header destroyed** — SQLite's 4-byte freeblock header overwrote the record
   header length too. Reconstructed from the serial-type array; corroborated by
   the surviving header-length byte where it exists. Confidence ×0.7.

A carved record is rejected outright if any text field contains a NUL or more
than 2% unprintable characters — that is the signature of a value that ran past
the end of its real field, and a half-fabricated message in a report is worse
than no message at all.

Regions searched: freeblocks, cell-pointer slack, freelist pages, `-wal`
frames, `-journal` page images.

---

## Supported artifacts

| Platform | Source | Recovers |
|---|---|---|
| Android | `calllog.db`, `contacts2.db` | Calls with direction/duration/presentation; contacts with all typed data rows |
| Android | `mmssms.db`, `bugle_db` | SMS, MMS with parts and addressees, RCS |
| Android | `msgstore.db`, `wa.db` | WhatsApp messages (both schema generations), calls, contacts, group membership |
| Android | Chrome `History` | Visits, downloads, keyword search terms |
| Android | `accounts.db`, `wpa_supplicant.conf`, `packages.list`, `build.prop` | Accounts, Wi-Fi networks, installed apps, device identity |
| iOS | `CallHistory.storedata` | Calls incl. FaceTime, Apple absolute time |
| iOS | `sms.db` | SMS/iMessage, group threads, attachments, **`attributedBody` text recovery** |
| iOS | `AddressBook.sqlitedb` | Contacts with multi-value phone/email/address |
| iOS | `History.db` | Safari history and search terms |
| iOS | `cache_encryptedA.db`, `routined.sqlite` | Significant locations, cell/Wi-Fi fixes |
| iOS | `NoteStore.sqlite`, `Calendar.sqlitedb` | Notes (gzip-inflated), calendar events |
| iOS | `ChatStorage.sqlite` | WhatsApp for iOS |
| Any | Images, video, audio, documents | EXIF, GPS, hashes, **extension/content mismatch detection** |
| Android | Telegram `cache4.db` | Messages, users, calls — text recovered from serialised TL blobs |
| Android | Instagram, Snapchat, Messenger, Discord, Viber | Direct messages, threads, friends; schema resolved at runtime |
| Android | Signal | Registration metadata (the store itself is SQLCipher) |
| Android | Gmail, Paytm/PhonePe/GPay, Google Maps | Mail snippets, UPI transactions, search and destination history |
| Android | `usagestats`, notification history | Device-use events; **notifications preview content from encrypted apps** |
| iOS | `KnowledgeC.db` | App focus, lock state, screen, Siri — the device-usage timeline |
| iOS | `CurrentPowerlog.PLSQL` | App runtime, corroborating KnowledgeC independently |
| SIM/USIM | Monolithic card dump | ICCID, IMSI, MCC/MNC, ADN phonebook, **deleted SMS and cleared contacts** |
| KaiOS | IndexedDB stores | Contacts, SMS, call log |
| Windows Phone | `store.vol`, `phone.db` | Contacts, SMS, call log by structured scraping |
| Feature phone | MTK/Series 30+ flat files | Contacts, SMS, media where structurally recognisable |
| SD card | Removable media, `LOST.DIR` | Media with EXIF/GPS, documents, orphaned files, carving |
| Wearable | Wear OS / watchOS / Fitbit | Mirrored notifications, health and activity, companion data |
| Any | Unrecognised app databases | Generic survey plus heuristic message extraction |

Files are typed by **magic bytes, not extension** — a JPEG renamed `invoice.txt`
is still found, flagged, and shown in the gallery. That case is in the test
suite.

Timestamps are normalised from Unix s/ms/µs/ns, Apple absolute, Apple ns,
WebKit, Windows FILETIME, Julian day and GPS epoch into a single UTC
microsecond representation — so a timeline spanning an iPhone and an Android
handset is actually comparable.

---

## Device and platform coverage

```
argus platforms          # everything ARGUS reads, and everything it does not
argus manual search "Redmi Note 12"
argus manual show "Galaxy S23"
```

**127 handsets across 24 manufacturers** — Apple, Samsung, Xiaomi/Redmi/Poco,
Google, OnePlus, Oppo, Vivo, Realme, Motorola, Huawei, Honor, Nokia, Sony, LG,
Asus, Nothing, Tecno, Infinix, itel, Lava, Micromax, Alcatel, Reliance, Fitbit —
plus SIM cards, KaiOS, Windows Phone, feature phones, SD cards and wearables.

Capability matrices are **generated** by `tools/build_catalog.py` from the OS
release and chipset family rather than hand-written per device, because a
hand-maintained matrix across several hundred handsets drifts, and a stale cell
is one an examiner trusts.

**For handsets that are not catalogued**, ARGUS reasons from what actually
governs acquisition rather than refusing:

| Factor | Why it decides the answer |
|---|---|
| Encryption era | Android none → FDE (5–9) → FBE (10+). FBE is why a BFU image is barren. |
| BootROM route | checkm8, MediaTek download agent, Unisoc diagnostic mode operate *below* the OS, so they ignore lock state. |
| Secure element | Secure Enclave, Titan M2, Knox rate-limit passcode attempts in hardware. |

```
$ argus manual show "Cubot King Kong 9"       # not in the catalogue
  inferred      True   confidence 0.75
  family        MediaTek (BootROM download mode)
  encryption    FBE
  bfu methods   physical, sim, screenshot
   - BootROM DA operates below the OS, so physical acquisition is a candidate
     at every lock state. Whether the resulting image is *readable* still
     depends on encryption.
```

That last sentence is the point. A BootROM exploit gets you an image; file-based
encryption still keeps the user data wrapped. Conflating "imaged" with "read" is
how a report over-promises, so the two are reported separately and an inferred
profile is never allowed to outrank a catalogued one.

---

## Command reference

```
argus app                        start the Workbench application (GUI)
argus intel                      investigative findings (lead sheet)
argus thread    --who "<name>"   read a conversation as a conversation
argus fuse                       attribute activity to a person, not a device
argus media                      visual matching — same picture, different files
argus hashset   --good/--bad     known-good suppression, known-bad flagging
argus validate                   measure the tool's own error rates
argus certificate issue|verify   evidence integrity certificate
argus devices                    detect connected handsets (§5.4)
argus manual search|show|list    device capability matrix (§5.1)
argus case new|list|show         case management (§5.2–5.3)
argus exhibit add                register a seized item
argus acquire                    run an extraction (§5.5–5.9)
argus verify                     re-verify container integrity (§7)
argus analyze                    open the analysis UI (§6)
argus query    --aql "..."       headless AQL search
argus stats                      statistics, bursts, gaps, anomalies
argus graph    --scope calls     connection analysis (§6.4, §6.6)
argus report   --formats ...     forensic report (§6.8)
argus carve                      standalone deleted-record recovery
argus parsers                    list registered parsers
```

Extraction methods: `logical` (content providers), `filesystem` (pulls
databases with their WAL sidecars — required for deleted-record recovery),
`backup` (`adb backup`), `import` (an existing folder, `.ab` file, or iOS
backup directory).

---

## Project layout

```
ARGUS.bat / .command / .sh   one-click launchers
argus_app.py                 application entry point + environment preflight
argus/
  core/        container, case, artifact DB, hashing, audit chain, models
  devices/     capability matrix (device manual), ADB/usbmux detection
  acquire/     engine, ADB, Android .ab backups, iOS backups, tree ingest
  parsers/     forensic SQLite reader + carver, plists, timestamps,
               android/, ios/, media/ artifact parsers
  analyze/     session, timeline, connection graph, AQL
  report/      HTML, PDF, XLSX, DOCX, XML, JSON, CSV exporters
  server/      workbench app server, analysis server, background jobs
  ui/          workbench.html (the app) + xamn.html (analysis views)
samples/       synthetic device generator, hand-rolled EXIF writer
tests/         86 tests
docs/          LAB_MAPPING.md — manual step → implementation
```

### How the app is put together

The Workbench is a stdlib `ThreadingHTTPServer` bound to `127.0.0.1` with no
third-party framework. Two decisions are worth knowing about:

**A session token, not just localhost.** The server mints a random token at
start-up and passes it to the browser in the URL fragment; every API call must
carry it. Binding to loopback alone is not enough — any web page open in the
same browser can issue requests to `localhost`, and an examiner's forensic tool
is not something a random site should be able to drive.

**Extractions run as background jobs with a resumable log.** An acquisition can
take hours, and the manual requires the operator to be able to watch the live
module/status/timestamp log. A blocking request would time out and show
nothing. Instead the engine's log lines are buffered with monotonic sequence
numbers and the UI asks for "everything after N", so a refreshed page or a
dropped connection cannot lose lines from what is part of the record of what
was done to the evidence.

---

## Tests

```bash
python tests/test_argus.py     # standalone, no pytest needed
python -m pytest tests/ -v
```

86 tests covering varint and serial-type decoding, epoch conversion, the audit
hash chain, capability gating, carver recall *and* false-positive rejection,
AQL parsing including injection resistance, graph identity resolution, blob and
database tamper detection, and a full acquire → decode → analyse → report
pipeline against a generated device tree.

Eleven of those drive the Workbench over real HTTP on a loopback port — the
token gate, the folder browser, the capability gate, a complete
case → exhibit → extraction → analysis → report workflow, and the resumability
of the live extraction log — so the JSON contract the UI depends on is covered,
not just the Python underneath it.

Two of those tests exist specifically because the carver and the device lookup
each failed them on first implementation: `test_does_not_invent_records` caught
the carver emitting a message body that ran past its real field, and
`test_unknown_device_refused` caught fuzzy matching resolving an unknown handset
to a real profile — which would have let the capability matrix authorise a
method the actual device does not support.

---

## Investigative intelligence

Beyond listing artifacts, ARGUS tells you what matters. Twelve auditable rules
produce ranked findings, each citing the artifacts behind it:

```bash
argus intel <container>... --owner "+919111222333"
```

On the bundled sample case it reports, unprompted:

```
[CRITICAL] Entire conversation with +919555000111 was deleted
           All 5 recovered messages came from deleted space;
           no live records with this correspondent survive
[CRITICAL] 3 messages from encrypted apps recovered via notifications
[CRITICAL] 2 shared contacts deleted on one device but not another
[HIGH]     1 file disguised by extension (invoice_2026.txt is a JPEG)
[MEDIUM]   56 device-usage events establish hands-on use
```

The notification finding is the one worth understanding. Signal keeps its store
encrypted, so its messages cannot be read. But the operating system writes a
*preview* of each incoming message into its own unencrypted notification
history — so content unreadable in the app is often perfectly readable a few
tables away. Finding it requires noticing that one source is encrypted *and*
that another contains its content, which is exactly the connection an examiner
working app-by-app will miss.

Three rules keep it honest:

- **Every finding cites its evidence.** A finding without artifact IDs is an
  assertion, and an assertion you cannot check is worse than nothing.
- **Rules describe, they do not accuse.** A rule reports *"contact reached only
  via a deleted thread, never saved to the address book"*. It does not report
  *"co-conspirator"*.
- **Every finding states its own caveat** — what would make it wrong. A lead
  presented without its counter-argument invites over-reading.

Entities are extracted from message content and **checksum-validated**: Bitcoin
(Base58Check and bech32), Ethereum, Monero, IBAN (mod-97), payment cards (Luhn
*plus* issuer IIN ranges), UPI, IMEI, Tor addresses, coordinates, vehicle
registrations. Luhn alone would call every IMEI a payment card — and "payment
card recovered from handset" is an allegation with consequences.

Across multiple exhibits it links the same person by exact shared identifier,
finds byte-identical media, and detects communities by label propagation with a
fixed seed so the same evidence always yields the same structure.

---

## Visual matching, threads and attribution

Three capabilities that go beyond listing artifacts.

**Perceptual image matching.** SHA-256 answers "same file?"; it cannot answer
"same photograph?". A picture forwarded through a messaging app, saved and
screenshotted becomes four files with four unrelated digests. Three perceptual
algorithms match them anyway — recompression q95→q35 gives a distance of 0, while
a genuinely different photograph scores 52. Hashes are computed at ingest and
sealed into the container.

```bash
argus media <container>
```

**Conversation reconstruction.** Messages threaded back into conversations, with
turn-taking, reply latency, and — most usefully — where the deleted messages sit.
A deleted message between two surviving ones is far more informative than the
same message alone:

```bash
argus thread <container> --who "9555000111"

2026-06-25T17:56:49  9555000111: The customs officer has been paid.  [RECOVERED FROM DELETED SPACE]
2026-06-25T18:07:49  9555000111: Move the container tonight, not tomorrow.  [RECOVERED …]
2026-06-25T18:29:49  9555000111: Meet at the old jetty, 02:00, come alone.  [RECOVERED …]
```

**Event fusion — attribution.** The question that decides contested cases is not
what the handset did but whether somebody was holding it. Device-usage telemetry
lives in stores independent of the messaging apps, so fusing them attributes acts
to a person:

```bash
argus fuse <container>

2026-06-14T21:50:00  [attributed]  strength=0.98  Are we still on for tomorrow?
    + usage    0.0s  KnowledgeC: WhatsApp in foreground (30s)
    + usage   -0.9s  PowerLog: WhatsApp running (20s)
    + lock    -5.0s  KnowledgeC: device unlocked
```

On the reference case: 90 attributed, 4 unattributed, **730 unknown**. That last
number is the honest part — most handsets keep telemetry for days, not months, so
most acts cannot be attributed. They are reported as `unknown`, never as "not the
owner". Attribution is always to *a person at the device*, never to a named
individual: anyone with the unlocked phone produces the same record.

**Hash-set filtering.** NSRL-style known-good suppression to cut review volume,
and known-bad flagging. Known-bad always beats known-good, matching is per
algorithm, and suppression never removes anything from the evidence.

```bash
argus hashset <container> --good nsrl.csv --bad blocklist.txt
```

---

## Validation — measured error rates

Asked in court what a tool's error rate is, "it works well" is not an answer.

```bash
argus validate --out validation.json
```

18 known-answer tests over a generated corpus where ground truth is exact by
construction:

```
tests 18/18 · overall recall 1.000 · precision 1.000 · 434 items · 0 missed

Anti-forensics detection  1.000/1.000    File carving         1.000/1.000
Deleted-record recovery   1.000/1.000    Evidence integrity   1.000/1.000
Entity extraction         1.000/1.000    Repeatability        1.000/1.000
Entity validation         1.000/1.000    Parsing              1.000/1.000
```

The harness proved its worth immediately: it first reported deleted-record
recall of **0.25**. Investigation showed 6 of 8 deleted rows were physically
absent from the file — SQLite compacts pages when freeing cells and overwrites
content outright. The carver had recovered both survivors, i.e. everything
recoverable. The *test* was wrong, measuring against an impossible standard, and
now measures against records whose bytes still exist while reporting the
destroyed count separately.

### Evidence certificate

```bash
argus certificate issue <container>... --validation validation.json --seal
argus certificate verify certificate.json --key certificate.json.key
```

A single JSON document holding every digest, the container seal, the custody
chain tip and the validated error rates at examination time. It is verifiable
**without ARGUS** — the steps in its own `how_to_verify` field need nothing but
a SHA-256 implementation, so an opposing expert can confirm or refute it
independently. The optional HMAC seal states plainly in the certificate that it
is *not* a digital signature and does not prove authorship.

---

## Anti-forensics detection

The absence of evidence is evidence, if the tool says so instead of reporting
"no messages found":

- **Encrypted stores** — SQLCipher (by entropy and page alignment), WhatsApp
  `.crypt14/15`. Reported as *encrypted*, never as empty, with the note that
  their content is excluded from artifact totals.
- **Vault and hider apps** — 38 known packages, plus their concealed media.
  Most consumer vaults only rename files, so the content is recoverable.
- **Thumbnail-cache recovery** — Android retains thumbnails after the source
  photo is deleted, so these are often the only surviving copies.
- **Uninstalled-app residue** and **factory-reset estimation**.
- **Recovery-limitation assessment** — whether a database *can* yield deleted
  records, determined by inspecting its actual free space. Notably this does
  *not* read `PRAGMA secure_delete`: that pragma reports the reading
  connection's setting, not the file's history, so using it would be simply
  wrong.

---

## Adversarial testing

Every other test in the suite feeds ARGUS files built by the same mind that
wrote the parsers. That is circular: the tool passes because the fixtures encode
the assumptions the code already makes. Two suites exist to break that circle.

**Corrupted evidence** (`tests/test_robustness.py`). Eleven mutators — truncation
at both ends, scattered bit-flips, zeroed erase blocks, damaged headers, spliced
halves, pure noise, repeated-byte padding, header-only fragments — applied to
nine evidence types at ten seeds. Roughly 1,000 parses per run, asserting two
properties:

- **No crash.** A parser that raises on exhibit 40 of 300 has silently removed a
  device from the examination, and a traceback mid-acquisition is
  indistinguishable from "this phone was empty".
- **No fabricated content.** Garbage must not yield confident-looking records. A
  crash is visible; an invented message attributed to a real number is not.

What that sweep found, none of which design review had caught:

| Defect | Consequence |
|---|---|
| Random bytes decoded as a SIM contact `"NW"` and a mojibake SMS | Invented evidence attributed to a real handset |
| `ZeroDivisionError` on a zeroed SQLite page-size field | Reads as a bug in ARGUS, not as a fact about damaged evidence |
| Leaked file handle on every failed reader construction | A pass over an exhibit of unreadable files exhausts the fd limit mid-acquisition |
| Truncated `"kCopyright MediaTek"` defeating a word-anchored marker | Firmware banner reported as a recovered message |

The character-statistics gates that let the first one through are now
structural: text must contain *words* — letter runs, with vowels, at a
reasonable density — not merely the right distribution of bytes.

**Schema variants** (`tests/test_schema_variants.py`). The same conversation
planted in four message schemas and two call schemas, asserting identical facts
come out of each. This caught the most serious defect of the session: Google
Messages (`bugle_db`, the default SMS app on modern Android) stores text in a
`parts` table joined by `message_id`, and the parser was reading a `text` column
that does not exist on the message row. It emitted one message per row with an
empty body — a report reading "12 messages" with twelve blanks under it.

It also produced a structural fix. A specific parser claiming a file used to
suppress the generic survey, which is right when it succeeds and wrong when it
does not: a renamed column meant the parser matched the filename, recognised
nothing, returned empty, and the file appeared in no view at all. When every
claiming parser decodes nothing, the survey now runs anyway and says why.

---

## Limitations

Stated plainly, because a forensic tool that overstates its reach is dangerous:

- **Encrypted evidence is not broken.** SQLCipher databases, encrypted iOS
  backups and WhatsApp `.crypt14` files are detected and reported as encrypted;
  ARGUS does not attempt to recover keys.
- **Live iOS acquisition** requires `idevicebackup2` to produce the backup
  first; ARGUS then imports it.
- **`adb backup`** is deprecated from Android 12 and most apps opt out — use
  the `filesystem` method, which needs root for `/data/data`.
- **Physical extraction** is listed in the capability matrix but not
  implemented; it depends on device-specific exploits.
- **Carved records may lack a rowid** and their timestamps can be missing when
  that column fell in the overwritten region. Confidence is always reported and
  always surfaced in the UI and reports.
- **The device catalogue is finite** (127 handsets across 24 manufacturers).
  A model that is not listed is *not* silently matched to a similar one —
  selection uses a hard score floor precisely so a near-miss cannot resolve to
  the wrong handset and authorise a method the real device does not support.
  For uncatalogued devices ARGUS derives a profile from the chipset family and
  OS release and labels it `inferred`; that profile is a documented starting
  point, not a tested result, and its confidence never reaches 1.0.
- **Inferred profiles are not validated on the model in question.** Verify on a
  test device of the same model before relying on one in a case.
- **The corpus is synthetic.** It reproduces documented schemas and is now
  attacked with mutations nobody designed for, but it is not a real caseload.
  Recall against an undocumented schema variant may be lower than the validation
  figures suggest. Where a schema is not recognised the file is surveyed and
  flagged rather than dropped, so the gap is visible — but it is still a gap.

## Legal

For use only on devices you own or are lawfully authorised to examine. Mobile
device data is highly personal; handle it under the applicable legal and
institutional framework. The bundled sample data is entirely synthetic.

MIT licensed.
