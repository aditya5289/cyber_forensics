"""MTP acquisition, and the shortfall Explorer never mentions.

Dragging a phone's storage out in Explorer works, and produces no hashes, no
record of what was taken, and no record of what was missed. That last gap is the
dangerous one: MTP transfers fail individually and quietly, so an examiner who
copies 4,000 files and receives 3,960 has no way to know. Concluding a
photograph was absent when the copy dropped it is an error that survives all the
way into a report.

These tests hold the two properties that make this an acquisition rather than a
file copy: every arrival is hashed, and every listed file that did not arrive is
named.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import unittest
from pathlib import Path

from argus.acquire import mtp


class Reconciliation(unittest.TestCase):
    """Comparing what was listed against what landed."""

    def setUp(self) -> None:
        self.dir = Path(tempfile.mkdtemp(prefix="argus-mtp-"))
        self.dest = self.dir / "dest"
        self.dest.mkdir()
        self._real_available = mtp.available
        self._real_list = mtp.list_tree
        self._real_shell = mtp._powershell
        mtp.available = lambda: True
        mtp._powershell = lambda script, timeout=900: ("DONE", "")

    def tearDown(self) -> None:
        mtp.available = self._real_available
        mtp.list_tree = self._real_list
        mtp._powershell = self._real_shell
        shutil.rmtree(self.dir, ignore_errors=True)

    def _land(self, relative: str, payload: bytes) -> None:
        target = self.dest / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)

    def test_a_complete_copy_reports_nothing_missing(self) -> None:
        mtp.list_tree = lambda name, max_depth=6: [
            {"kind": "F", "path": "DCIM/IMG_001.jpg", "size": 10},
            {"kind": "F", "path": "DCIM/IMG_002.jpg", "size": 10},
        ]
        self._land("DCIM/IMG_001.jpg", b"0123456789")
        self._land("DCIM/IMG_002.jpg", b"0123456789")

        result = mtp.acquire("PHONE", self.dest)
        self.assertEqual(result.files_copied, 2)
        self.assertEqual(result.missing, [])
        self.assertTrue(result.complete)

    def test_a_dropped_file_is_named(self) -> None:
        """The whole point. Explorer would report success and move on."""
        mtp.list_tree = lambda name, max_depth=6: [
            {"kind": "F", "path": "DCIM/IMG_001.jpg", "size": 10},
            {"kind": "F", "path": "DCIM/IMG_LOCKED.jpg", "size": 4096},
        ]
        self._land("DCIM/IMG_001.jpg", b"0123456789")

        result = mtp.acquire("PHONE", self.dest)
        self.assertFalse(result.complete)
        self.assertEqual(len(result.missing), 1)
        self.assertEqual(result.missing[0]["path"], "DCIM/IMG_LOCKED.jpg")

    def test_the_shortfall_carries_a_warning_not_just_a_count(self) -> None:
        mtp.list_tree = lambda name, max_depth=6: [
            {"kind": "F", "path": "a.jpg", "size": 1},
            {"kind": "F", "path": "b.jpg", "size": 1},
        ]
        self._land("a.jpg", b"x")
        result = mtp.acquire("PHONE", self.dest)
        joined = " ".join(result.warnings)
        self.assertIn("did not arrive", joined)

    def test_absence_is_never_stated_as_a_finding(self) -> None:
        """A missing file means the copy failed, not that the phone lacked it.

        Reversing those two is how a report ends up asserting something the
        evidence does not support.
        """
        mtp.list_tree = lambda name, max_depth=6: [
            {"kind": "F", "path": "gone.jpg", "size": 1}]
        result = mtp.acquire("PHONE", self.dest)
        self.assertIn("not necessarily absent", result.method_note)
        self.assertIn("Do not treat their absence",
                      " ".join(result.warnings))

    def test_directories_are_not_counted_as_missing_files(self) -> None:
        mtp.list_tree = lambda name, max_depth=6: [
            {"kind": "D", "path": "DCIM", "size": 0},
            {"kind": "F", "path": "DCIM/a.jpg", "size": 1},
        ]
        self._land("DCIM/a.jpg", b"x")
        self.assertEqual(mtp.acquire("PHONE", self.dest).missing, [])


class Hashing(unittest.TestCase):
    def setUp(self) -> None:
        self.dir = Path(tempfile.mkdtemp(prefix="argus-mtp-hash-"))
        self.dest = self.dir / "dest"
        self.dest.mkdir()
        self._real_available = mtp.available
        self._real_list = mtp.list_tree
        self._real_shell = mtp._powershell
        mtp.available = lambda: True
        mtp._powershell = lambda script, timeout=900: ("DONE", "")
        mtp.list_tree = lambda name, max_depth=6: [
            {"kind": "F", "path": "photo.jpg", "size": 5}]

    def tearDown(self) -> None:
        mtp.available = self._real_available
        mtp.list_tree = self._real_list
        mtp._powershell = self._real_shell
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_every_arrival_is_hashed(self) -> None:
        payload = b"hello"
        (self.dest / "photo.jpg").write_bytes(payload)
        result = mtp.acquire("PHONE", self.dest)
        self.assertEqual(result.hashes["photo.jpg"],
                         hashlib.sha256(payload).hexdigest())

    def test_hashing_can_be_skipped_deliberately(self) -> None:
        (self.dest / "photo.jpg").write_bytes(b"hello")
        result = mtp.acquire("PHONE", self.dest, hash_files=False)
        self.assertEqual(result.hashes, {})

    def test_manifest_records_hashes_and_shortfall(self) -> None:
        (self.dest / "photo.jpg").write_bytes(b"hello")
        result = mtp.acquire("PHONE", self.dest)
        target = mtp.write_manifest(result, self.dir / "manifest.json")
        data = json.loads(target.read_text(encoding="utf-8"))
        self.assertIn("hashes", data)
        self.assertIn("missing", data)
        self.assertIn("method_note", data)
        self.assertEqual(data["format"], "argus-mtp-manifest/1")


class StatesWhatItIs(unittest.TestCase):
    """MTP is a media-provider copy, and the report must not imply otherwise."""

    def test_the_method_note_disclaims_being_an_image(self) -> None:
        self.assertIn("not an image", mtp.METHOD_NOTE)

    def test_the_method_note_names_what_it_cannot_reach(self) -> None:
        self.assertIn("/data/data", mtp.METHOD_NOTE)

    def test_the_method_note_warns_about_access_times(self) -> None:
        self.assertIn("access time", mtp.METHOD_NOTE)


class DegradesQuietly(unittest.TestCase):
    def test_unsupported_platform_explains_the_alternative(self) -> None:
        real = mtp.available
        mtp.available = lambda: False
        try:
            result = mtp.acquire("PHONE", tempfile.mkdtemp())
            self.assertTrue(result.warnings)
            self.assertIn("mount the handset", " ".join(result.warnings))
        finally:
            mtp.available = real

    def test_no_devices_is_not_an_error(self) -> None:
        real = mtp.available
        mtp.available = lambda: False
        try:
            self.assertEqual(mtp.devices(), [])
        finally:
            mtp.available = real


if __name__ == "__main__":
    unittest.main()
